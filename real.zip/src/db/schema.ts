import {
  pgTable,
  text,
  timestamp,
  integer,
  boolean,
  json,
  uuid,
  pgEnum,
  real,
} from "drizzle-orm/pg-core";

export const roleEnum = pgEnum("role", ["admin", "user"]);

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").unique().notNull(),
  username: text("username").unique().notNull(),
  passwordHash: text("password_hash").notNull(),
  role: roleEnum("role").default("user").notNull(),
  avatar: text("avatar"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const minecraftPlans = pgTable("minecraft_plans", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  ram: text("ram").notNull(), // e.g. "2GB", "4GB"
  cpu: text("cpu").notNull(), // e.g. "2 vCores"
  storage: text("storage").notNull(), // e.g. "10GB NVMe"
  slots: text("slots").notNull(), // e.g. "Unlimited"
  priceMonthly: real("price_monthly").notNull(),
  priceQuarterly: real("price_quarterly").notNull(),
  priceYearly: real("price_yearly").notNull(),
  features: json("features").$type<string[]>().default([]).notNull(),
  icon: text("icon").default("🟩"),
  color: text("color").default("#3B82F6"),
  popular: boolean("popular").default(false).notNull(),
  active: boolean("active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const vpsPlans = pgTable("vps_plans", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  cpuCores: text("cpu_cores").notNull(), // e.g. "2 vCores"
  ram: text("ram").notNull(), // e.g. "4GB"
  storage: text("storage").notNull(), // e.g. "50GB NVMe"
  bandwidth: text("bandwidth").notNull(), // e.g. "2TB"
  priceMonthly: real("price_monthly").notNull(),
  priceQuarterly: real("price_quarterly").notNull(),
  priceYearly: real("price_yearly").notNull(),
  features: json("features").$type<string[]>().default([]).notNull(),
  icon: text("icon").default("🖥️"),
  color: text("color").default("#8B5CF6"),
  popular: boolean("popular").default(false).notNull(),
  active: boolean("active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const settings = pgTable("settings", {
  id: uuid("id").primaryKey().defaultRandom(),
  key: text("key").unique().notNull(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  token: text("token").unique().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
