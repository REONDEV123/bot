import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-brand-500/10 bg-surface-950/80 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-sm font-black text-white">
                U
              </div>
              <span className="text-lg font-bold">
                UIA <span className="text-brand-400">Host</span>
              </span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Premium Minecraft and VPS hosting with enterprise-grade infrastructure. 
              Power your gaming with UIA Host.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Products</h4>
            <div className="space-y-2">
              {["Minecraft Hosting", "VPS Hosting", "Dedicated Servers", "Game Servers"].map((item) => (
                <Link key={item} href="#" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  {item}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Company</h4>
            <div className="space-y-2">
              {["About Us", "Blog", "Status", "Affiliates"].map((item) => (
                <Link key={item} href="#" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  {item}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Support</h4>
            <div className="space-y-2">
              {["Knowledge Base", "Contact Us", "Discord", "Terms of Service"].map((item) => (
                <Link key={item} href="#" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  {item}
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-brand-500/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} UIA Host. All rights reserved.
          </p>
          <p className="text-gray-600 text-xs">
            Powered by UIA Host Technology
          </p>
        </div>
      </div>
    </footer>
  );
}
