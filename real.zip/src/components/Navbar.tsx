"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);

  useEffect(() => {
    fetch("/api/auth/session")
      .then((r) => r.json())
      .then((d) => d.user && setUser(d.user))
      .catch(() => {});
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "glass border-b border-brand-500/10 py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-lg font-black text-white shadow-lg shadow-brand-500/30 group-hover:shadow-brand-500/50 transition-shadow">
            U
          </div>
          <span className="text-xl font-bold tracking-tight">
            UIA <span className="text-brand-400">Host</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="#plans" className="text-sm text-gray-300 hover:text-white transition-colors">
            Minecraft Plans
          </Link>
          <Link href="#vps" className="text-sm text-gray-300 hover:text-white transition-colors">
            VPS Plans
          </Link>
          <Link href="#features" className="text-sm text-gray-300 hover:text-white transition-colors">
            Features
          </Link>
          {user ? (
            <Link
              href={user.role === "admin" ? "/admin" : "/dashboard"}
              className="px-4 py-2 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium transition-colors"
            >
              {user.role === "admin" ? "Admin Panel" : "Dashboard"}
            </Link>
          ) : (
            <Link
              href="/login"
              className="px-4 py-2 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium transition-colors"
            >
              Login
            </Link>
          )}
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden p-2 text-gray-300 hover:text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {mobileOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden glass border-t border-brand-500/10">
          <div className="px-4 py-4 space-y-3">
            <Link href="#plans" className="block text-gray-300 hover:text-white py-2" onClick={() => setMobileOpen(false)}>
              Minecraft Plans
            </Link>
            <Link href="#vps" className="block text-gray-300 hover:text-white py-2" onClick={() => setMobileOpen(false)}>
              VPS Plans
            </Link>
            <Link href="#features" className="block text-gray-300 hover:text-white py-2" onClick={() => setMobileOpen(false)}>
              Features
            </Link>
            {user ? (
              <Link
                href={user.role === "admin" ? "/admin" : "/dashboard"}
                className="block px-4 py-2 rounded-lg bg-brand-600 text-white text-center font-medium"
                onClick={() => setMobileOpen(false)}
              >
                {user.role === "admin" ? "Admin Panel" : "Dashboard"}
              </Link>
            ) : (
              <Link
                href="/login"
                className="block px-4 py-2 rounded-lg bg-brand-600 text-white text-center font-medium"
                onClick={() => setMobileOpen(false)}
              >
                Login
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
