"use client";

import { useRef, useMemo, useState, useEffect } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import {
  Text3D,
  OrbitControls,
  Float,
  Environment,
  MeshTransmissionMaterial,
} from "@react-three/drei";
import * as THREE from "three";

function GrassBlock({ position, scale = 1 }: { position: [number, number, number]; scale?: number }) {
  const mesh = useRef<THREE.Mesh>(null!);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (mesh.current) {
      mesh.current.rotation.y += 0.005;
      mesh.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
      mesh.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 1.2 + position[0]) * 0.15;
    }
  });

  const texture = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext("2d")!;

    // Top face - green grass
    ctx.fillStyle = "#5D8A3C";
    ctx.fillRect(0, 0, 256, 256);
    ctx.fillStyle = "#4A7A2E";
    for (let i = 0; i < 60; i++) {
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 4, 8);
    }
    ctx.fillStyle = "#6B9B4A";
    for (let i = 0; i < 30; i++) {
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 6, 4);
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    return tex;
  }, []);

  const sideTexture = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#8B6914";
    ctx.fillRect(0, 0, 256, 256);
    ctx.fillStyle = "#A07818";
    for (let i = 0; i < 30; i++) {
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 12, 12);
    }
    ctx.fillStyle = "#6B4F10";
    for (let i = 0; i < 20; i++) {
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 6, 6);
    }
    const tex2 = new THREE.CanvasTexture(canvas);
    tex2.wrapS = THREE.RepeatWrapping;
    tex2.wrapT = THREE.RepeatWrapping;
    return tex2;
  }, []);

  return (
    <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.3}>
      <mesh
        ref={mesh}
        position={position}
        scale={hovered ? scale * 1.15 : scale}
        onPointerEnter={() => setHovered(true)}
        onPointerLeave={() => setHovered(false)}
      >
        <boxGeometry args={[1, 1, 1]} />
        {[
          null, // right
          null, // left
          { map: texture }, // top
          { map: sideTexture }, // bottom
          { map: sideTexture }, // front
          { map: sideTexture }, // back
        ].map((matProps, i) => (
          <meshStandardMaterial key={i} attach={`material-${i}`} color={i === 2 ? "#7CBA3D" : "#C8973E"} roughness={0.6} metalness={0.1} />
        ))}
      </mesh>
    </Float>
  );
}

function FloatingBlocks() {
  const blocks = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        position: [
          (Math.random() - 0.5) * 8,
          (Math.random() - 0.5) * 4,
          (Math.random() - 0.5) * 6 - 2,
        ] as [number, number, number],
        scale: 0.6 + Math.random() * 1.2,
        key: i,
      })),
    []
  );

  return (
    <>
      {blocks.map((b) => (
        <GrassBlock key={b.key} position={b.position} scale={b.scale} />
      ))}
    </>
  );
}

function ParticleField() {
  const count = 200;
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 15;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 10;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 8;
    }
    return pos;
  }, []);

  const points = useRef<THREE.Points>(null!);

  useFrame((state) => {
    if (points.current) {
      points.current.rotation.y += 0.0003;
      points.current.rotation.x += 0.0001;
    }
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial size={0.03} color="#8B5CF6" transparent opacity={0.6} sizeAttenuation />
    </points>
  );
}

function GroundPlane() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3, 0]} receiveShadow>
      <planeGeometry args={[20, 20]} />
      <meshStandardMaterial color="#1a1a2e" transparent opacity={0.3} />
    </mesh>
  );
}

export default function ThreeScene() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#111133] to-[#0a0a2e]" />
    );
  }

  return (
    <div className="absolute inset-0 -z-10">
      <Canvas
        camera={{ position: [0, 0, 7], fov: 55 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
      >
        <ambientLight intensity={0.4} />
        <directionalLight position={[5, 5, 5]} intensity={0.8} />
        <pointLight position={[-5, 3, 3]} intensity={0.5} color="#8B5CF6" />
        <pointLight position={[5, -1, -2]} intensity={0.4} color="#3B82F6" />
        <FloatingBlocks />
        <ParticleField />
        <GroundPlane />
        <Environment preset="city" />
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          autoRotate
          autoRotateSpeed={0.4}
          maxPolarAngle={Math.PI / 1.8}
          minPolarAngle={Math.PI / 3}
        />
      </Canvas>
    </div>
  );
}
