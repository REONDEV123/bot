"use client";

import { useState, useEffect } from "react";

interface Plan {
  id: string;
  name: string;
  ram: string;
  cpu: string;
  storage: string;
  slots: string;
  priceMonthly: number;
  priceQuarterly: number;
  priceYearly: number;
  features: string[];
  icon: string;
  color: string;
  popular: boolean;
}

interface VPSPlan {
  id: string;
  name: string;
  cpuCores: string;
  ram: string;
  storage: string;
  bandwidth: string;
  priceMonthly: number;
  priceQuarterly: number;
  priceYearly: number;
  features: string[];
  icon: string;
  color: string;
  popular: boolean;
}

type BillingCycle = "monthly" | "quarterly" | "yearly";

function PlanCard({ plan, billing }: { plan: Plan; billing: BillingCycle }) {
  const price =
    billing === "monthly"
      ? plan.priceMonthly
      : billing === "quarterly"
        ? plan.priceQuarterly
        : plan.priceYearly;

  const discount =
    billing === "yearly" ? "Save 20%" : billing === "quarterly" ? "Save 10%" : null;

  return (
    <div
      className={`relative glass-light rounded-2xl p-6 sm:p-8 transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl group ${
        plan.popular ? "ring-2 ring-brand-500 shadow-lg shadow-brand-500/20" : ""
      }`}
    >
      {plan.popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-brand-600 text-white text-xs font-bold">
          MOST POPULAR
        </div>
      )}

      <div className="flex items-center gap-3 mb-5">
        <span className="text-3xl">{plan.icon}</span>
        <h3 className="text-xl font-bold">{plan.name}</h3>
      </div>

      <div className="mb-6">
        <span className="text-4xl font-extrabold">${price.toFixed(2)}</span>
        <span className="text-gray-400 text-sm">/{billing === "monthly" ? "mo" : billing === "quarterly" ? "3mo" : "yr"}</span>
        {discount && (
          <span className="ml-2 text-xs px-2 py-0.5 rounded bg-green-500/20 text-green-400">
            {discount}
          </span>
        )}
      </div>

      <div className="space-y-3 mb-6">
        {[
          { icon: "🧠", label: plan.ram, sub: "RAM" },
          { icon: "⚙️", label: plan.cpu, sub: "CPU" },
          { icon: "💾", label: plan.storage, sub: "Storage" },
          { icon: "👥", label: plan.slots, sub: "Slots" },
        ].map((spec) => (
          <div key={spec.sub} className="flex items-center gap-3 text-sm">
            <span className="text-lg">{spec.icon}</span>
            <span className="text-gray-300">
              <strong>{spec.label}</strong> {spec.sub}
            </span>
          </div>
        ))}
      </div>

      <div className="space-y-2 mb-8">
        {plan.features.map((f) => (
          <div key={f} className="flex items-center gap-2 text-sm text-gray-400">
            <svg className="w-4 h-4 text-green-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            {f}
          </div>
        ))}
      </div>

      <button className="w-full py-3 rounded-lg bg-brand-600 hover:bg-brand-500 text-white font-semibold transition-colors">
        Order Now
      </button>
    </div>
  );
}

function VPSPlanCard({ plan, billing }: { plan: VPSPlan; billing: BillingCycle }) {
  const price =
    billing === "monthly"
      ? plan.priceMonthly
      : billing === "quarterly"
        ? plan.priceQuarterly
        : plan.priceYearly;

  return (
    <div className="glass-light rounded-2xl p-6 sm:p-8 transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl group">
      {plan.popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-purple-600 text-white text-xs font-bold">
          RECOMMENDED
        </div>
      )}
      <div className="flex items-center gap-3 mb-5">
        <span className="text-3xl">{plan.icon}</span>
        <h3 className="text-xl font-bold">{plan.name}</h3>
      </div>
      <div className="mb-6">
        <span className="text-4xl font-extrabold">${price.toFixed(2)}</span>
        <span className="text-gray-400 text-sm">/{billing === "monthly" ? "mo" : billing === "quarterly" ? "3mo" : "yr"}</span>
      </div>
      <div className="space-y-3 mb-6">
        {[
          { icon: "⚙️", label: plan.cpuCores, sub: "CPU" },
          { icon: "🧠", label: plan.ram, sub: "RAM" },
          { icon: "💾", label: plan.storage, sub: "NVMe" },
          { icon: "🌐", label: plan.bandwidth, sub: "Bandwidth" },
        ].map((spec) => (
          <div key={spec.sub} className="flex items-center gap-3 text-sm">
            <span className="text-lg">{spec.icon}</span>
            <span className="text-gray-300">
              <strong>{spec.label}</strong> {spec.sub}
            </span>
          </div>
        ))}
      </div>
      <div className="space-y-2 mb-8">
        {plan.features.map((f) => (
          <div key={f} className="flex items-center gap-2 text-sm text-gray-400">
            <svg className="w-4 h-4 text-purple-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            {f}
          </div>
        ))}
      </div>
      <button className="w-full py-3 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold transition-colors">
        Deploy Now
      </button>
    </div>
  );
}

export default function PlansSection() {
  const [billing, setBilling] = useState<BillingCycle>("monthly");
  const [mcPlans, setMcPlans] = useState<Plan[]>([]);
  const [vpsPlans, setVpsPlans] = useState<VPSPlan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/plans/minecraft").then((r) => r.json()),
      fetch("/api/plans/vps").then((r) => r.json()),
    ])
      .then(([mc, vps]) => {
        setMcPlans(mc);
        setVpsPlans(vps);
      })
      .finally(() => setLoading(false));
  }, []);

  const defaultMcPlans: Plan[] = [
    {
      id: "1",
      name: "Starter",
      ram: "2GB",
      cpu: "2 vCores",
      storage: "10GB NVMe",
      slots: "Unlimited",
      priceMonthly: 4.99,
      priceQuarterly: 13.47,
      priceYearly: 47.90,
      features: ["DDoS Protection", "Instant Setup", "Full FTP Access", "Free MySQL", "24/7 Support"],
      icon: "🟩",
      color: "#3B82F6",
      popular: false,
    },
    {
      id: "2",
      name: "Advanced",
      ram: "4GB",
      cpu: "4 vCores",
      storage: "25GB NVMe",
      slots: "Unlimited",
      priceMonthly: 9.99,
      priceQuarterly: 26.97,
      priceYearly: 95.90,
      features: ["Everything in Starter", "Modpack Support", "Automated Backups", "Priority Support", "Dedicated IP"],
      icon: "🟨",
      color: "#F59E0B",
      popular: true,
    },
    {
      id: "3",
      name: "Pro",
      ram: "8GB",
      cpu: "6 vCores",
      storage: "50GB NVMe",
      slots: "Unlimited",
      priceMonthly: 19.99,
      priceQuarterly: 53.97,
      priceYearly: 191.90,
      features: ["Everything in Advanced", "Dedicated Resources", "Custom JAR Support", "Plugin Installer", "Premium Support"],
      icon: "🟥",
      color: "#EF4444",
      popular: false,
    },
  ];

  const defaultVpsPlans: VPSPlan[] = [
    {
      id: "v1",
      name: "VPS Basic",
      cpuCores: "2 vCores",
      ram: "2GB",
      storage: "30GB NVMe",
      bandwidth: "1TB",
      priceMonthly: 5.99,
      priceQuarterly: 16.17,
      priceYearly: 57.50,
      features: ["Full Root Access", "SSH Access", "Choice of OS", "1 IPv4 Address"],
      icon: "🖥️",
      color: "#8B5CF6",
      popular: false,
    },
    {
      id: "v2",
      name: "VPS Pro",
      cpuCores: "4 vCores",
      ram: "4GB",
      storage: "60GB NVMe",
      bandwidth: "2TB",
      priceMonthly: 11.99,
      priceQuarterly: 32.37,
      priceYearly: 115.10,
      features: ["Full Root Access", "SSH Access", "Choice of OS", "DDOS Protection", "2 IPv4 Addresses"],
      icon: "💻",
      color: "#8B5CF6",
      popular: true,
    },
    {
      id: "v3",
      name: "VPS Elite",
      cpuCores: "8 vCores",
      ram: "8GB",
      storage: "120GB NVMe",
      bandwidth: "4TB",
      priceMonthly: 23.99,
      priceQuarterly: 64.77,
      priceYearly: 230.30,
      features: ["Full Root Access", "SSH Access", "Choice of OS", "DDOS Protection", "Priority Support", "4 IPv4 Addresses"],
      icon: "🖥️",
      color: "#8B5CF6",
      popular: false,
    },
  ];

  const displayMc = mcPlans.length > 0 ? mcPlans : defaultMcPlans;
  const displayVps = vpsPlans.length > 0 ? vpsPlans : defaultVpsPlans;

  return (
    <>
      {/* Minecraft Plans */}
      <section id="plans" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl sm:text-5xl font-extrabold mb-4">
              Minecraft <span className="text-gradient">Plans</span>
            </h2>
            <p className="text-gray-400 max-w-xl mx-auto">
              Choose the perfect plan for your server. All plans include DDoS protection and 24/7 support.
            </p>

            {/* Billing toggle */}
            <div className="inline-flex items-center mt-8 glass-light rounded-xl p-1">
              {(["monthly", "quarterly", "yearly"] as BillingCycle[]).map((b) => (
                <button
                  key={b}
                  onClick={() => setBilling(b)}
                  className={`px-5 py-2 rounded-lg text-sm font-medium transition-all capitalize ${
                    billing === b
                      ? "bg-brand-600 text-white shadow-lg"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="glass-light rounded-2xl p-8 animate-pulse">
                  <div className="h-8 w-24 bg-white/5 rounded mb-4" />
                  <div className="h-12 w-32 bg-white/5 rounded mb-6" />
                  <div className="space-y-3">
                    <div className="h-4 bg-white/5 rounded" />
                    <div className="h-4 bg-white/5 rounded" />
                    <div className="h-4 bg-white/5 rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8 relative">
              {displayMc.map((plan) => (
                <PlanCard key={plan.id} plan={plan} billing={billing} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* VPS Plans */}
      <section id="vps" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl sm:text-5xl font-extrabold mb-4">
              VPS <span className="text-gradient">Hosting</span>
            </h2>
            <p className="text-gray-400 max-w-xl mx-auto">
              Powerful virtual private servers for your applications. Full root access, instant deployment.
            </p>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="glass-light rounded-2xl p-8 animate-pulse">
                  <div className="h-8 w-24 bg-white/5 rounded mb-4" />
                  <div className="h-12 w-32 bg-white/5 rounded mb-6" />
                  <div className="space-y-3">
                    <div className="h-4 bg-white/5 rounded" />
                    <div className="h-4 bg-white/5 rounded" />
                    <div className="h-4 bg-white/5 rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8 relative">
              {displayVps.map((plan) => (
                <VPSPlanCard key={plan.id} plan={plan} billing={billing} />
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
