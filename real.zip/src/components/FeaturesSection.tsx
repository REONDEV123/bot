export default function FeaturesSection() {
  const features = [
    {
      icon: "⚡",
      title: "Instant Setup",
      desc: "Your server is ready within 60 seconds of ordering. No waiting, no hassle.",
    },
    {
      icon: "🛡️",
      title: "DDoS Protection",
      desc: "Enterprise-grade DDoS mitigation keeps your server online 24/7.",
    },
    {
      icon: "💾",
      title: "NVMe SSD Storage",
      desc: "Blazing-fast NVMe storage ensures minimal lag and instant chunk loading.",
    },
    {
      icon: "🔄",
      title: "Automated Backups",
      desc: "Daily automated backups with 7-day retention to keep your data safe.",
    },
    {
      icon: "🌍",
      title: "Global Network",
      desc: "Multiple data centers worldwide for low-latency connections everywhere.",
    },
    {
      icon: "🎮",
      title: "Modpack Support",
      desc: "One-click install for popular modpacks like FTB, CurseForge, and more.",
    },
    {
      icon: "💬",
      title: "24/7 Support",
      desc: "Expert support team available round-the-clock via ticket and live chat.",
    },
    {
      icon: "🔧",
      title: "Full Control",
      desc: "Full FTP access, custom JAR support, and complete server configuration.",
    },
  ];

  return (
    <section id="features" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <h2 className="text-4xl sm:text-5xl font-extrabold mb-4">
            Why Choose <span className="text-gradient">UIA Host</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            Everything you need for the ultimate Minecraft hosting experience.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f) => (
            <div
              key={f.title}
              className="glass-light rounded-2xl p-6 transition-all duration-300 hover:scale-105 hover:shadow-xl group"
            >
              <div className="text-3xl mb-4">{f.icon}</div>
              <h3 className="font-bold text-lg mb-2 group-hover:text-brand-400 transition-colors">
                {f.title}
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
