import Link from "next/link";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 pt-20">
      <div className="max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-light text-sm text-brand-300 mb-8 animate-float">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          99.9% Uptime SLA • DDoS Protected • 24/7 Support
        </div>

        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-tight">
          Premium{" "}
          <span className="text-gradient">Minecraft</span>
          <br />
          Server Hosting
        </h1>

        <p className="mt-6 text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Power your Minecraft world with blazing-fast NVMe storage, 
          enterprise-grade DDoS protection, and instant setup. 
          From vanilla to modded — we handle the tech, you play.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="#plans"
            className="px-8 py-4 rounded-xl bg-gradient-to-r from-brand-600 to-purple-600 text-white font-semibold text-lg hover:from-brand-500 hover:to-purple-500 transition-all shadow-lg shadow-brand-600/30 hover:shadow-brand-500/40 hover:scale-105 transform"
          >
            View Minecraft Plans
          </Link>
          <Link
            href="#vps"
            className="px-8 py-4 rounded-xl glass-light text-white font-semibold text-lg hover:bg-white/10 transition-all border border-white/10"
          >
            VPS Hosting →
          </Link>
        </div>

        <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-2xl mx-auto">
          {[
            { label: "Instant Setup", icon: "⚡" },
            { label: "NVMe Storage", icon: "💾" },
            { label: "DDoS Protected", icon: "🛡️" },
            { label: "7-Day Backup", icon: "📦" },
          ].map((item) => (
            <div key={item.label} className="glass-light rounded-xl p-4 text-center">
              <div className="text-2xl mb-1">{item.icon}</div>
              <div className="text-xs text-gray-400 font-medium">{item.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
