import { db } from "@/db";
import { vpsPlans } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    await requireAdmin();
    const plans = await db
      .select()
      .from(vpsPlans)
      .orderBy(vpsPlans.sortOrder);
    return NextResponse.json(plans);
  } catch (error: unknown) {
    if (error instanceof Error && error.message.includes("Unauthorized")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const body = await request.json();
    const {
      name, cpuCores, ram, storage, bandwidth,
      priceMonthly, priceQuarterly, priceYearly,
      features, icon, color, popular, active, sortOrder,
    } = body;

    if (!name || !cpuCores || !ram || !storage || !bandwidth || !priceMonthly || !priceQuarterly || !priceYearly) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const [plan] = await db
      .insert(vpsPlans)
      .values({
        name, cpuCores, ram, storage, bandwidth,
        priceMonthly, priceQuarterly, priceYearly,
        features: features || [],
        icon: icon || "🖥️",
        color: color || "#8B5CF6",
        popular: popular || false,
        active: active ?? true,
        sortOrder: sortOrder || 0,
      })
      .returning();

    return NextResponse.json(plan);
  } catch (error: unknown) {
    if (error instanceof Error && error.message.includes("Unauthorized")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
