import { db } from "@/db";
import { minecraftPlans } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const plans = await db
    .select()
    .from(minecraftPlans)
    .where(eq(minecraftPlans.active, true))
    .orderBy(minecraftPlans.sortOrder);
  return NextResponse.json(plans);
}
