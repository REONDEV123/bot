import { db } from "@/db";
import { vpsPlans } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const plans = await db
    .select()
    .from(vpsPlans)
    .where(eq(vpsPlans.active, true))
    .orderBy(vpsPlans.sortOrder);
  return NextResponse.json(plans);
}
