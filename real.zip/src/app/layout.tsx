import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "UIA Host - Premium Minecraft & VPS Hosting",
  description:
    "High-performance Minecraft server hosting and VPS solutions. 24/7 support, DDoS protection, instant setup. Power your gaming with UIA Host.",
  keywords: ["minecraft hosting", "vps hosting", "game servers", "minecraft server", "uia host"],
  openGraph: {
    title: "UIA Host - Premium Minecraft & VPS Hosting",
    description: "High-performance Minecraft server hosting and VPS solutions.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-surface-950 text-white antialiased">{children}</body>
    </html>
  );
}
