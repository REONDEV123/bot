import ThreeScene from "@/components/ThreeScene";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import PlansSection from "@/components/PlansSection";
import FeaturesSection from "@/components/FeaturesSection";
import Footer from "@/components/Footer";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <ThreeScene />
      <div className="relative z-10">
        <Navbar />
        <HeroSection />
        <PlansSection />
        <FeaturesSection />
        <Footer />
      </div>
    </div>
  );
}
