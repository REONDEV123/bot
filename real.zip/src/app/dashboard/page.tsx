"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<{ username: string; email: string; role: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/auth/session")
      .then((r) => r.json())
      .then((data) => {
        if (!data.user) {
          router.push("/login");
          return;
        }
        setUser(data.user);
      })
      .finally(() => setLoading(false));
  }, [router]);

  const handleLogout = async () => {
    await fetch("/api/auth/session", { method: "POST" });
    router.push("/login");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-surface-950 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface-950">
      <div className="fixed inset-0 -z-10 bg-grid opacity-30" />
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-sm font-black text-white">U</div>
            <span className="font-bold">UIA Host</span>
          </Link>
          <div className="flex items-center gap-4">
            {user?.role === "admin" && (
              <Link href="/admin" className="text-sm text-brand-400 hover:text-brand-300">Admin Panel</Link>
            )}
            <button onClick={handleLogout} className="text-sm text-gray-400 hover:text-white transition-colors">
              Logout
            </button>
          </div>
        </div>

        <div className="glass rounded-2xl p-8 mb-8">
          <h1 className="text-2xl font-bold mb-2">Welcome back, {user?.username}!</h1>
          <p className="text-gray-400">Manage your servers and account from this dashboard.</p>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div className="glass-light rounded-2xl p-6">
            <div className="text-3xl mb-3">🎮</div>
            <h3 className="font-bold text-lg mb-1">Minecraft Servers</h3>
            <p className="text-gray-400 text-sm mb-4">You have no active servers.</p>
            <Link href="/" className="text-sm text-brand-400 hover:text-brand-300">
              Browse Plans →
            </Link>
          </div>
          <div className="glass-light rounded-2xl p-6">
            <div className="text-3xl mb-3">💻</div>
            <h3 className="font-bold text-lg mb-1">VPS Instances</h3>
            <p className="text-gray-400 text-sm mb-4">You have no active VPS instances.</p>
            <Link href="/" className="text-sm text-brand-400 hover:text-brand-300">
              Browse Plans →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
