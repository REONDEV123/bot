"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminSettings() {
  const router = useRouter();
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [newKey, setNewKey] = useState("");
  const [newValue, setNewValue] = useState("");

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((res) => {
        if (res.status === 401) { router.push("/login"); return {}; }
        return res.json();
      })
      .then((data) => {
        setSettings(data || {});
        setLoading(false);
      });
  }, [router]);

  const saveSetting = async (key: string, value: string) => {
    setSaving(key);
    await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, value }),
    });
    setSaving(null);
  };

  const addSetting = async () => {
    if (!newKey.trim()) return;
    const res = await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: newKey, value: newValue }),
    });
    if (res.ok) {
      setSettings((prev) => ({ ...prev, [newKey]: newValue }));
      setNewKey("");
      setNewValue("");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const predefinedSettings = [
    { key: "site_name", label: "Site Name", description: "The name of your hosting company" },
    { key: "site_description", label: "Site Description", description: "Meta description for SEO" },
    { key: "support_email", label: "Support Email", description: "Customer support email address" },
    { key: "discord_url", label: "Discord URL", description: "Link to your Discord server" },
    { key: "currency", label: "Currency", description: "Currency code (e.g., USD, EUR)" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Settings</h1>

      <div className="glass rounded-2xl p-6 mb-8">
        <h2 className="text-lg font-bold mb-6">Site Settings</h2>
        <div className="space-y-5">
          {predefinedSettings.map(({ key, label, description }) => (
            <div key={key} className="flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex-1">
                <label className="text-sm font-medium">{label}</label>
                <p className="text-xs text-gray-500">{description}</p>
              </div>
              <div className="flex gap-2">
                <input
                  className="px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none w-64"
                  value={settings[key] || ""}
                  onChange={(e) => setSettings({ ...settings, [key]: e.target.value })}
                />
                <button
                  onClick={() => saveSetting(key, settings[key] || "")}
                  disabled={saving === key}
                  className="px-4 py-2 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium transition-colors disabled:opacity-50"
                >
                  {saving === key ? "Saving" : "Save"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <h2 className="text-lg font-bold mb-4">Add Custom Setting</h2>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            className="flex-1 px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none"
            placeholder="Setting key"
            value={newKey}
            onChange={(e) => setNewKey(e.target.value)}
          />
          <input
            className="flex-1 px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none"
            placeholder="Value"
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
          />
          <button
            onClick={addSetting}
            className="px-4 py-2 rounded-lg bg-surface-700 hover:bg-surface-600 text-white text-sm font-medium transition-colors"
          >
            Add
          </button>
        </div>

        {/* Custom settings list */}
        {Object.keys(settings).filter(k => !predefinedSettings.find(p => p.key === k)).length > 0 && (
          <div className="mt-6 space-y-3">
            {Object.entries(settings)
              .filter(([key]) => !predefinedSettings.find((p) => p.key === key))
              .map(([key, value]) => (
                <div key={key} className="flex items-center gap-3 p-3 rounded-lg bg-surface-800">
                  <span className="text-sm font-mono text-brand-400">{key}</span>
                  <span className="text-sm text-gray-400 flex-1">{value}</span>
                  <button
                    onClick={() => saveSetting(key, value)}
                    className="px-3 py-1 rounded bg-surface-700 hover:bg-surface-600 text-xs transition-colors"
                  >
                    Edit
                  </button>
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
}
