"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";

interface MCPlan {
  id: string;
  name: string;
  ram: string;
  cpu: string;
  storage: string;
  slots: string;
  priceMonthly: number;
  priceQuarterly: number;
  priceYearly: number;
  features: string[];
  icon: string;
  color: string;
  popular: boolean;
  active: boolean;
  sortOrder: number;
}

const EMPTY: MCPlan = {
  id: "",
  name: "",
  ram: "",
  cpu: "",
  storage: "",
  slots: "",
  priceMonthly: 0,
  priceQuarterly: 0,
  priceYearly: 0,
  features: [],
  icon: "🟩",
  color: "#3B82F6",
  popular: false,
  active: true,
  sortOrder: 0,
};

export default function AdminMCPlans() {
  const router = useRouter();
  const [plans, setPlans] = useState<MCPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<MCPlan | null>(null);
  const [form, setForm] = useState<MCPlan>(EMPTY);
  const [featuresInput, setFeaturesInput] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/admin/minecraft-plans");
    if (res.status === 401) { router.push("/login"); return; }
    const data = await res.json();
    setPlans(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [router]);

  useEffect(() => { load(); }, [load]);

  const openNew = () => {
    setEditing(null);
    setForm({ ...EMPTY });
    setFeaturesInput("");
  };

  const openEdit = (plan: MCPlan) => {
    setEditing(plan);
    setForm({ ...plan });
    setFeaturesInput((plan.features || []).join("\n"));
  };

  const handleSave = async () => {
    setSaving(true);
    const body = { ...form, features: featuresInput.split("\n").filter(Boolean) };
    const url = editing
      ? `/api/admin/minecraft-plans/${editing.id}`
      : "/api/admin/minecraft-plans";
    const method = editing ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (res.status === 401) { router.push("/login"); return; }
    if (res.ok) {
      setEditing(null);
      setForm(EMPTY);
      setFeaturesInput("");
      await load();
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this plan?")) return;
    await fetch(`/api/admin/minecraft-plans/${id}`, { method: "DELETE" });
    await load();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Minecraft Plans</h1>
        <button
          onClick={openNew}
          className="px-4 py-2 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium transition-colors"
        >
          + Add Plan
        </button>
      </div>

      {/* Form */}
      {(editing || (!editing && form.name === "" && plans.length === 0)) && (
        <div className="glass rounded-2xl p-6 mb-8">
          <h2 className="text-lg font-bold mb-4">{editing ? "Edit Plan" : "New Plan"}</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Name</label>
              <input className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">RAM</label>
              <input className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.ram} onChange={e => setForm({ ...form, ram: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">CPU</label>
              <input className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.cpu} onChange={e => setForm({ ...form, cpu: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Storage</label>
              <input className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.storage} onChange={e => setForm({ ...form, storage: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Slots</label>
              <input className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.slots} onChange={e => setForm({ ...form, slots: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Icon</label>
              <input className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.icon} onChange={e => setForm({ ...form, icon: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Color</label>
              <input type="color" className="w-full h-10 rounded-lg bg-surface-800 border border-surface-700 cursor-pointer" value={form.color} onChange={e => setForm({ ...form, color: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Price Monthly ($)</label>
              <input type="number" step="0.01" className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.priceMonthly} onChange={e => setForm({ ...form, priceMonthly: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Price Quarterly ($)</label>
              <input type="number" step="0.01" className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.priceQuarterly} onChange={e => setForm({ ...form, priceQuarterly: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Price Yearly ($)</label>
              <input type="number" step="0.01" className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.priceYearly} onChange={e => setForm({ ...form, priceYearly: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Sort Order</label>
              <input type="number" className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.sortOrder} onChange={e => setForm({ ...form, sortOrder: parseInt(e.target.value) || 0 })} />
            </div>
          </div>

          <div className="mt-4">
            <label className="block text-xs text-gray-400 mb-1">Features (one per line)</label>
            <textarea
              className="w-full px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none"
              rows={5}
              value={featuresInput}
              onChange={e => setFeaturesInput(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-4 mt-4">
            <label className="flex items-center gap-2 text-sm text-gray-300">
              <input type="checkbox" checked={form.popular} onChange={e => setForm({ ...form, popular: e.target.checked })} className="rounded" />
              Popular
            </label>
            <label className="flex items-center gap-2 text-sm text-gray-300">
              <input type="checkbox" checked={form.active} onChange={e => setForm({ ...form, active: e.target.checked })} className="rounded" />
              Active
            </label>
          </div>

          <div className="flex gap-3 mt-6">
            <button onClick={handleSave} disabled={saving} className="px-5 py-2 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium transition-colors disabled:opacity-50">
              {saving ? "Saving..." : "Save Plan"}
            </button>
            <button onClick={() => { setEditing(null); setForm(EMPTY); }} className="px-5 py-2 rounded-lg bg-surface-700 hover:bg-surface-600 text-gray-300 text-sm font-medium transition-colors">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Plans Table */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-surface-700">
                <th className="text-left p-4 text-gray-400 font-medium">Name</th>
                <th className="text-left p-4 text-gray-400 font-medium">Specs</th>
                <th className="text-left p-4 text-gray-400 font-medium">Monthly</th>
                <th className="text-left p-4 text-gray-400 font-medium">Status</th>
                <th className="text-right p-4 text-gray-400 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {plans.map((plan) => (
                <tr key={plan.id} className="border-b border-surface-700/50 hover:bg-surface-800/50">
                  <td className="p-4">
                    <span className="mr-2">{plan.icon}</span>
                    <span className="font-medium">{plan.name}</span>
                    {plan.popular && <span className="ml-2 px-2 py-0.5 text-xs rounded bg-brand-600/20 text-brand-400">Popular</span>}
                  </td>
                  <td className="p-4 text-gray-400">{plan.ram} / {plan.cpu} / {plan.storage}</td>
                  <td className="p-4 font-medium">${plan.priceMonthly.toFixed(2)}</td>
                  <td className="p-4">
                    <span className={`px-2 py-0.5 text-xs rounded ${plan.active ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                      {plan.active ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button onClick={() => openEdit(plan)} className="px-3 py-1 rounded bg-surface-700 hover:bg-surface-600 text-xs mr-2 transition-colors">Edit</button>
                    <button onClick={() => handleDelete(plan.id)} className="px-3 py-1 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs transition-colors">Delete</button>
                  </td>
                </tr>
              ))}
              {plans.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-gray-500">No plans yet. Click &quot;Add Plan&quot; to create one.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
