"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface Stats {
  mcPlans: number;
  vpsPlans: number;
  users: number;
  activeServers: number;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<Stats>({ mcPlans: 0, vpsPlans: 0, users: 0, activeServers: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [mcRes, vpsRes, usersRes] = await Promise.all([
          fetch("/api/admin/minecraft-plans"),
          fetch("/api/admin/vps-plans"),
          fetch("/api/admin/users"),
        ]);

        if (mcRes.status === 401 || vpsRes.status === 401 || usersRes.status === 401) {
          router.push("/login");
          return;
        }

        const [mc, vps, users] = await Promise.all([
          mcRes.json(),
          vpsRes.json(),
          usersRes.json(),
        ]);

        setStats({
          mcPlans: Array.isArray(mc) ? mc.length : 0,
          vpsPlans: Array.isArray(vps) ? vps.length : 0,
          users: Array.isArray(users) ? users.length : 0,
          activeServers: Array.isArray(mc) ? mc.filter((p: { active: boolean }) => p.active).length : 0,
        });
      } catch (err) {
        console.error("Failed to load stats:", err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [router]);

  const cards = [
    { label: "Minecraft Plans", value: stats.mcPlans, icon: "🟩", color: "from-green-500/20 to-emerald-500/20" },
    { label: "VPS Plans", value: stats.vpsPlans, icon: "🖥️", color: "from-purple-500/20 to-violet-500/20" },
    { label: "Total Users", value: stats.users, icon: "👥", color: "from-blue-500/20 to-cyan-500/20" },
    { label: "Active Plans", value: stats.activeServers, icon: "✅", color: "from-brand-500/20 to-indigo-500/20" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Admin Dashboard</h1>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="glass-light rounded-2xl p-6 animate-pulse">
              <div className="h-4 w-20 bg-white/5 rounded mb-4" />
              <div className="h-8 w-12 bg-white/5 rounded" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {cards.map((card) => (
            <div
              key={card.label}
              className={`glass-light rounded-2xl p-6 bg-gradient-to-br ${card.color}`}
            >
              <div className="text-2xl mb-2">{card.icon}</div>
              <div className="text-3xl font-bold mb-1">{card.value}</div>
              <div className="text-sm text-gray-400">{card.label}</div>
            </div>
          ))}
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="glass rounded-2xl p-6">
          <h2 className="text-lg font-bold mb-4">Quick Actions</h2>
          <div className="space-y-3">
            {[
              { href: "/admin/minecraft-plans", label: "Add Minecraft Plan", icon: "🟩" },
              { href: "/admin/vps-plans", label: "Add VPS Plan", icon: "🖥️" },
              { href: "/admin/settings", label: "Update Settings", icon: "⚙️" },
            ].map((action) => (
              <a
                key={action.label}
                href={action.href}
                className="flex items-center gap-3 p-3 rounded-lg bg-surface-800 hover:bg-surface-700 transition-colors"
              >
                <span className="text-xl">{action.icon}</span>
                <span className="text-sm font-medium">{action.label}</span>
                <span className="ml-auto text-gray-500">→</span>
              </a>
            ))}
          </div>
        </div>

        <div className="glass rounded-2xl p-6">
          <h2 className="text-lg font-bold mb-4">System Info</h2>
          <div className="space-y-3 text-sm">
            {[
              { label: "Platform", value: "Next.js 16 + PostgreSQL" },
              { label: "Port", value: "3000 (HTTP)" },
              { label: "Proxy", value: "Cloudflare Compatible" },
              { label: "Database", value: "PostgreSQL via Drizzle ORM" },
              { label: "Auth", value: "JWT + HTTP Cookies" },
            ].map((item) => (
              <div key={item.label} className="flex justify-between py-2 border-b border-surface-700 last:border-0">
                <span className="text-gray-400">{item.label}</span>
                <span className="text-white font-medium">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
