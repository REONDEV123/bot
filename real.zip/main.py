#!/usr/bin/env python3
"""
UIA Host - VPS Deployment Manager
==================================
This script manages the UIA Host Next.js application on a VPS.
It handles: installation, building, starting, stopping, and monitoring
the application. Designed to work behind Cloudflare on port 3000 (HTTP).

Usage:
    python3 main.py install      - Install dependencies and set up
    python3 main.py build        - Build the production application
    python3 main.py start        - Start the production server
    python3 main.py stop         - Stop the running server
    python3 main.py restart      - Restart the server
    python3 main.py status       - Check server status
    python3 main.py setup-admin  - Create the initial admin user
    python3 main.py dev          - Start development server
    python3 main.py logs         - Show recent server logs
    python3 main.py db-push      - Push database schema changes

Environment:
    Requires Python 3.8+
    Node.js 18+ and npm must be installed
    PostgreSQL must be running and accessible
"""

import os
import sys
import json
import signal
import subprocess
import time
import socket
import getpass
from pathlib import Path
from typing import Optional

# ============================================================
# Configuration
# ============================================================

APP_NAME = "uia-host"
APP_DIR = Path(__file__).parent.resolve()
PID_FILE = APP_DIR / ".pid"
LOG_FILE = APP_DIR / "server.log"
ENV_FILE = APP_DIR / ".env"
PORT = 3000
HOST = "0.0.0.0"  # Bind to all interfaces for Cloudflare

DEFAULT_ENV = {
    "DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:5432/app_db",
    "JWT_SECRET": "change-this-to-a-random-secret-string",
    "NODE_ENV": "production",
    "PORT": str(PORT),
    "HOSTNAME": HOST,
}


def print_banner():
    """Print the UIA Host banner."""
    banner = r"""
    ╦ ╦╦╔═   ╦ ╦╔═╗╔═╗╔╦╗
    ║ ║╠╩╗   ╠═╣║ ║╚═╗ ║
    ╚═╝╩ ╩   ╩ ╩╚═╝╚═╝ ╩
    Premium Minecraft & VPS Hosting
    ==================================
    """
    print(banner)


def run_cmd(cmd: list[str], cwd: Optional[Path] = None, check: bool = True) -> subprocess.CompletedProcess:
    """Run a shell command and return the result."""
    cwd = cwd or APP_DIR
    return subprocess.run(cmd, cwd=str(cwd), check=check, capture_output=False)


def run_cmd_output(cmd: list[str], cwd: Optional[Path] = None) -> str:
    """Run a command and return its stdout."""
    cwd = cwd or APP_DIR
    result = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True)
    return result.stdout.strip()


def ensure_env():
    """Ensure .env file exists with required variables."""
    if not ENV_FILE.exists():
        print("[*] Creating .env file...")
        with open(ENV_FILE, "w") as f:
            for key, value in DEFAULT_ENV.items():
                f.write(f"{key}={value}\n")
        print(f"[+] Created .env at {ENV_FILE}")
        print("[!] Please edit .env with your actual database credentials and JWT secret.")
    else:
        print(f"[*] .env file exists at {ENV_FILE}")

    # Check critical vars
    with open(ENV_FILE) as f:
        content = f.read()

    if "JWT_SECRET=change-this" in content:
        print("[!] WARNING: JWT_SECRET is still set to the default value. Please change it!")


def check_node():
    """Check if Node.js is installed."""
    try:
        version = run_cmd_output(["node", "--version"])
        print(f"[*] Node.js version: {version}")
        return True
    except FileNotFoundError:
        print("[!] ERROR: Node.js is not installed. Please install Node.js 18+.")
        return False


def check_npm():
    """Check if npm is installed."""
    try:
        version = run_cmd_output(["npm", "--version"])
        print(f"[*] npm version: {version}")
        return True
    except FileNotFoundError:
        print("[!] ERROR: npm is not installed.")
        return False


def check_postgres():
    """Check if PostgreSQL is accessible."""
    env = read_env()
    db_url = env.get("DATABASE_URL", "")
    if not db_url:
        print("[!] No DATABASE_URL configured.")
        return False

    try:
        import urllib.parse
        # Simple check - try to connect via pg_isready
        result = subprocess.run(
            ["pg_isready", "-h", "127.0.0.1", "-p", "5432"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            print("[*] PostgreSQL is running and accepting connections.")
            return True
        else:
            print("[!] PostgreSQL not reachable. Make sure it's running.")
            return False
    except FileNotFoundError:
        print("[*] pg_isready not found, skipping PostgreSQL check.")
        return True


def read_env() -> dict:
    """Read .env file into a dictionary."""
    if not ENV_FILE.exists():
        return {}
    env = {}
    with open(ENV_FILE) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                env[key.strip()] = value.strip()
    return env


def is_port_in_use(port: int) -> bool:
    """Check if a port is in use."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def get_pid() -> Optional[int]:
    """Get the PID of the running server."""
    if PID_FILE.exists():
        try:
            return int(PID_FILE.read_text().strip())
        except (ValueError, FileNotFoundError):
            return None
    return None


def is_running() -> bool:
    """Check if the server is running."""
    pid = get_pid()
    if pid is None:
        return False
    try:
        os.kill(pid, 0)  # Signal 0 just checks existence
        return True
    except (OSError, ProcessLookupError):
        return False


# ============================================================
# Commands
# ============================================================

def cmd_install():
    """Install dependencies."""
    print("[*] Installing npm dependencies...")
    ensure_env()

    if not check_node() or not check_npm():
        sys.exit(1)

    run_cmd(["npm", "install"])
    print("[+] Dependencies installed successfully.")
    print("[*] Run 'python3 main.py setup-admin' to create your admin account.")


def cmd_build():
    """Build the Next.js application for production."""
    print("[*] Building Next.js application...")
    ensure_env()

    run_cmd(["npm", "run", "build"])
    print("[+] Build completed successfully.")


def cmd_start():
    """Start the production server."""
    if is_running():
        print(f"[!] Server is already running (PID: {get_pid()})")
        return

    ensure_env()
    check_postgres()

    print(f"[*] Starting UIA Host on http://{HOST}:{PORT}")

    # Open log file
    log_fh = open(LOG_FILE, "a")
    log_fh.write(f"\n--- Server started at {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
    log_fh.flush()

    # Start the Next.js production server
    process = subprocess.Popen(
        ["npx", "next", "start", "-p", str(PORT), "-H", HOST],
        cwd=str(APP_DIR),
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        preexec_fn=os.setsid,  # Create new process group
        env={**os.environ, "NODE_ENV": "production"},
    )

    # Write PID
    PID_FILE.write_text(str(process.pid))

    # Wait a moment and check
    time.sleep(3)
    if process.poll() is not None:
        print(f"[!] Server exited immediately with code {process.returncode}")
        print(f"[!] Check logs: {LOG_FILE}")
        PID_FILE.unlink(missing_ok=True)
        return

    print(f"[+] Server started successfully (PID: {process.pid})")
    print(f"[*] Listening on http://{HOST}:{PORT}")
    print(f"[*] Logs: {LOG_FILE}")
    print(f"[*] Make sure Cloudflare is proxying to this port.")


def cmd_stop():
    """Stop the running server."""
    pid = get_pid()
    if pid is None:
        print("[!] No server PID found. Server may not be running.")
        return

    if not is_running():
        print(f"[!] Process {pid} is not running. Cleaning up PID file.")
        PID_FILE.unlink(missing_ok=True)
        return

    print(f"[*] Stopping server (PID: {pid})...")

    # Send SIGTERM to the process group
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except ProcessLookupError:
        pass

    # Wait for graceful shutdown
    for _ in range(10):
        if not is_running():
            break
        time.sleep(0.5)
    else:
        print("[!] Server didn't stop gracefully. Force killing...")
        try:
            os.killpg(os.getpgid(pid), signal.SIGKILL)
        except ProcessLookupError:
            pass

    PID_FILE.unlink(missing_ok=True)
    print("[+] Server stopped.")


def cmd_restart():
    """Restart the server."""
    print("[*] Restarting server...")
    if is_running():
        cmd_stop()
        time.sleep(1)
    cmd_start()


def cmd_status():
    """Check server status."""
    pid = get_pid()
    if pid and is_running():
        print(f"[+] Server is RUNNING (PID: {pid})")
        if is_port_in_use(PORT):
            print(f"[+] Port {PORT} is listening (HTTP)")
        else:
            print(f"[!] Port {PORT} is NOT listening yet")
    else:
        print("[-] Server is STOPPED")
        if pid:
            PID_FILE.unlink(missing_ok=True)


def cmd_setup_admin():
    """Create the initial admin user."""
    ensure_env()

    if is_running():
        print("[*] Server is running. Using API to create admin...")
        import urllib.request

        # Check if admin exists
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{PORT}/api/admin/setup")
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read())
                if data.get("hasAdmin"):
                    print("[!] An admin user already exists.")
                    return
        except Exception:
            pass

        email = input("Admin email: ").strip()
        username = input("Admin username: ").strip()
        password = getpass.getpass("Admin password: ")

        data = json.dumps({"email": email, "username": username, "password": password}).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{PORT}/api/admin/setup",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        try:
            with urllib.request.urlopen(req) as resp:
                result = json.loads(resp.read())
                if result.get("success"):
                    print(f"[+] Admin user '{username}' created successfully!")
                else:
                    print(f"[!] Error: {result.get('error', 'Unknown error')}")
        except urllib.error.HTTPError as e:
            error_body = e.read().decode()
            print(f"[!] HTTP Error: {error_body}")
    else:
        print("[!] Server is not running. Please start the server first:")
        print("    python3 main.py start")
        print("    Then: python3 main.py setup-admin")


def cmd_dev():
    """Start development server."""
    ensure_env()
    print(f"[*] Starting development server on http://localhost:{PORT}")
    run_cmd(["npm", "run", "dev"])


def cmd_logs():
    """Show recent server logs."""
    if not LOG_FILE.exists():
        print("[!] No log file found.")
        return

    with open(LOG_FILE) as f:
        lines = f.readlines()

    # Show last 50 lines
    for line in lines[-50:]:
        print(line, end="")


def cmd_db_push():
    """Push database schema changes."""
    ensure_env()
    print("[*] Pushing database schema...")
    run_cmd(["npx", "drizzle-kit", "push"])
    print("[+] Schema pushed successfully.")


# ============================================================
# Cloudflare Setup Helper
# ============================================================

def cmd_cloudflare_info():
    """Print Cloudflare configuration information."""
    print_banner()
    print("Cloudflare Tunnel / Proxy Configuration")
    print("=" * 50)
    print()
    print("This app runs on HTTP port 3000.")
    print("To expose it through Cloudflare, you have two options:")
    print()
    print("Option 1: Cloudflare Tunnel (cloudflared)")
    print("  Install cloudflared:")
    print("    curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared")
    print("    chmod +x cloudflared")
    print("  Create tunnel:")
    print("    ./cloudflared tunnel create uia-host")
    print("  Configure and run:")
    print("    ./cloudflared tunnel route dns uia-host yourdomain.com")
    print("    ./cloudflared tunnel run --url http://localhost:3000 uia-host")
    print()
    print("Option 2: Cloudflare Proxy (Orange Cloud)")
    print("  - Point your domain's DNS A record to your VPS IP")
    print("  - Enable Cloudflare proxy (orange cloud)")
    print("  - In Cloudflare SSL/TLS, set to 'Flexible' or 'Full'")
    print("  - The app runs on port 3000, so use a reverse proxy or iptables:")
    print()
    print("  Using iptables to forward port 80 → 3000:")
    print("    sudo iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 3000")
    print()
    print("  Using nginx as reverse proxy:")
    print("    server {")
    print("        listen 80;")
    print("        server_name yourdomain.com;")
    print("        location / {")
    print("            proxy_pass http://127.0.0.1:3000;")
    print("            proxy_http_version 1.1;")
    print("            proxy_set_header Upgrade $http_upgrade;")
    print("            proxy_set_header Connection 'upgrade';")
    print("            proxy_set_header Host $host;")
    print("            proxy_set_header X-Real-IP $remote_addr;")
    print("            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;")
    print("            proxy_set_header X-Forwarded-Proto $scheme;")
    print("            proxy_cache_bypass $http_upgrade;")
    print("        }")
    print("    }")
    print()


# ============================================================
# Main
# ============================================================

COMMANDS = {
    "install": cmd_install,
    "build": cmd_build,
    "start": cmd_start,
    "stop": cmd_stop,
    "restart": cmd_restart,
    "status": cmd_status,
    "setup-admin": cmd_setup_admin,
    "dev": cmd_dev,
    "logs": cmd_logs,
    "db-push": cmd_db_push,
    "cloudflare-info": cmd_cloudflare_info,
}


def main():
    print_banner()

    if len(sys.argv) < 2:
        print("Usage: python3 main.py <command>")
        print()
        print("Available commands:")
        for name, func in COMMANDS.items():
            doc = func.__doc__ or ""
            first_line = doc.strip().split("\n")[0] if doc else ""
            print(f"  {name:<18} {first_line}")
        print()
        print("Quick start:")
        print("  1. python3 main.py install")
        print("  2. python3 main.py build")
        print("  3. python3 main.py start")
        print("  4. python3 main.py setup-admin")
        print("  5. python3 main.py cloudflare-info")
        sys.exit(0)

    command = sys.argv[1]

    if command not in COMMANDS:
        print(f"[!] Unknown command: {command}")
        print(f"    Available: {', '.join(COMMANDS.keys())}")
        sys.exit(1)

    try:
        COMMANDS[command]()
    except KeyboardInterrupt:
        print("\n[!] Cancelled.")
        sys.exit(130)
    except Exception as e:
        print(f"[!] Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
