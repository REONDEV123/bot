import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Trust Cloudflare proxy headers
  allowedDevOrigins: ["*"],
  // Output as standalone for easier VPS deployment
  output: "standalone",
};

export default nextConfig;
