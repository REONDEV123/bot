/**
 * Command Handler - Feathernodes Help Bot
 * Loads all slash commands from the commands directory
 */

const fs   = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

module.exports = (client) => {
  const commands    = [];
  const commandsDir = path.join(__dirname, '..', 'commands');
  const categories  = fs.readdirSync(commandsDir);

  for (const category of categories) {
    const categoryPath = path.join(commandsDir, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const commandFiles = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
    for (const file of commandFiles) {
      try {
        const command = require(path.join(categoryPath, file));
        if (!command.data || !command.execute) {
          console.warn(`[CMD HANDLER] ⚠ Skipping ${file}: missing data or execute`);
          continue;
        }
        client.commands.set(command.data.name, command);
        commands.push(command.data.toJSON());
        console.log(`[CMD HANDLER] ✓ Loaded: /${command.data.name} (${category})`);
      } catch (err) {
        console.error(`[CMD HANDLER] ✗ Error loading ${file}:`, err.message);
      }
    }
  }

  // Deploy commands once client is ready
  client.once('ready', async () => {
    try {
      const rest = new REST().setToken(process.env.DISCORD_TOKEN);
      console.log(`[CMD HANDLER] 📡 Deploying ${commands.length} slash commands...`);

      if (process.env.GUILD_ID) {
        // Guild commands (instant update, good for development)
        await rest.put(
          Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
          { body: commands }
        );
        console.log(`[CMD HANDLER] ✅ Deployed ${commands.length} guild commands to ${process.env.GUILD_ID}`);
      } else {
        // Global commands (up to 1 hour to propagate)
        await rest.put(
          Routes.applicationCommands(process.env.CLIENT_ID),
          { body: commands }
        );
        console.log(`[CMD HANDLER] ✅ Deployed ${commands.length} global slash commands`);
      }
    } catch (err) {
      console.error('[CMD HANDLER] ✗ Deploy error:', err.message);
    }
  });
};
