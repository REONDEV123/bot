/**
 * Event Handler - Feathernodes Help Bot
 * Loads all event listeners from the events directory
 */

const fs   = require('fs');
const path = require('path');

module.exports = (client) => {
  const eventsDir = path.join(__dirname, '..', 'events');
  const categories = fs.readdirSync(eventsDir);

  for (const category of categories) {
    const categoryPath = path.join(eventsDir, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const eventFiles = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
    for (const file of eventFiles) {
      try {
        const event = require(path.join(categoryPath, file));
        if (!event.name || !event.execute) {
          console.warn(`[EVT HANDLER] ⚠ Skipping ${file}: missing name or execute`);
          continue;
        }
        if (event.once) {
          client.once(event.name, (...args) => event.execute(client, ...args));
        } else {
          client.on(event.name, (...args) => event.execute(client, ...args));
        }
        console.log(`[EVT HANDLER] ✓ Loaded: ${event.name} (${category})`);
      } catch (err) {
        console.error(`[EVT HANDLER] ✗ Error loading ${file}:`, err.message);
      }
    }
  }
};
