/**
 * Music Handler - Feathernodes Help Bot
 * Sets up DisTube music player with full event handling
 */

const { DisTube } = require('distube');
const { YtDlpPlugin } = require('@distube/yt-dlp');
const { SpotifyPlugin } = require('@distube/spotify');
const { SoundCloudPlugin } = require('@distube/soundcloud');
const { EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../utils/constants');

module.exports = (client) => {
  if (process.env.MUSIC_ENABLED === 'false') return;

  client.distube = new DisTube(client, {
    emitNewSongOnly: false,
    leaveOnEmpty:    true,
    leaveOnFinish:   false,
    leaveOnStop:     true,
    savePreviousSongs: true,
    nsfw:            false,
    emitAddSongWhenCreatingQueue: true,
    emitAddListWhenCreatingQueue: true,
    plugins: [
      new YtDlpPlugin({ update: false }),
      new SpotifyPlugin({
        emitEventsAfterFetching: true,
        parallel: true,
      }),
      new SoundCloudPlugin(),
    ],
  });

  const distube = client.distube;

  // ─── Now Playing ─────────────────────────────────────────────
  distube.on('playSong', (queue, song) => {
    const embed = new EmbedBuilder()
      .setColor(Colors.MUSIC)
      .setTitle(`${Emojis.MUSIC} Now Playing`)
      .setDescription(`**[${song.name}](${song.url})**`)
      .setThumbnail(song.thumbnail)
      .addFields(
        { name: '⏱️ Duration',    value: song.formattedDuration, inline: true },
        { name: '🎤 Requested By', value: `${song.user}`,         inline: true },
        { name: '🔊 Volume',       value: `${queue.volume}%`,      inline: true },
        { name: '🔁 Loop',         value: queue.repeatMode === 0 ? 'Off' : queue.repeatMode === 1 ? 'Song' : 'Queue', inline: true },
        { name: '📃 Queue',        value: `${queue.songs.length} song(s)`, inline: true },
      )
      .setFooter({ text: `Feathernodes Help | Credit: reondev`, iconURL: client.user?.displayAvatarURL() })
      .setTimestamp();

    queue.textChannel?.send({ embeds: [embed] });
  });

  // ─── Song Added ───────────────────────────────────────────────
  distube.on('addSong', (queue, song) => {
    const embed = new EmbedBuilder()
      .setColor(Colors.SUCCESS)
      .setDescription(`${Emojis.SUCCESS} Added **[${song.name}](${song.url})** to queue (Position: **#${queue.songs.length}**)`)
      .setThumbnail(song.thumbnail);
    queue.textChannel?.send({ embeds: [embed] });
  });

  // ─── Playlist Added ───────────────────────────────────────────
  distube.on('addList', (queue, playlist) => {
    const embed = new EmbedBuilder()
      .setColor(Colors.SUCCESS)
      .setDescription(`${Emojis.SUCCESS} Added playlist **${playlist.name}** (${playlist.songs.length} songs) to queue!`);
    queue.textChannel?.send({ embeds: [embed] });
  });

  // ─── Queue Finished ───────────────────────────────────────────
  distube.on('finish', (queue) => {
    const embed = new EmbedBuilder()
      .setColor(Colors.INFO)
      .setDescription(`${Emojis.INFO} Queue finished! Use \`/play\` to add more songs.`);
    queue.textChannel?.send({ embeds: [embed] });
  });

  // ─── Empty Queue ─────────────────────────────────────────────
  distube.on('empty', (queue) => {
    const embed = new EmbedBuilder()
      .setColor(Colors.WARNING)
      .setDescription(`${Emojis.WARNING} Voice channel is empty! Leaving the channel.`);
    queue.textChannel?.send({ embeds: [embed] });
  });

  // ─── Disconnect ───────────────────────────────────────────────
  distube.on('disconnect', (queue) => {
    const embed = new EmbedBuilder()
      .setColor(Colors.ERROR)
      .setDescription(`${Emojis.ERROR} Disconnected from voice channel.`);
    queue.textChannel?.send({ embeds: [embed] });
  });

  // ─── Error ────────────────────────────────────────────────────
  distube.on('error', (channel, error) => {
    console.error('[DISTUBE ERROR]', error);
    const embed = new EmbedBuilder()
      .setColor(Colors.ERROR)
      .setDescription(`${Emojis.ERROR} Music error: \`${error.message}\``);
    if (channel) channel.send({ embeds: [embed] });
  });

  // ─── Search Result ────────────────────────────────────────────
  distube.on('searchResult', (message, result) => {
    const desc = result.map((s, i) => `**${i + 1}.** ${s.name} (${s.formattedDuration})`).join('\n');
    const embed = new EmbedBuilder()
      .setColor(Colors.INFO)
      .setTitle(`${Emojis.MUSIC} Search Results`)
      .setDescription(desc + '\n\nType a number (1-10) to select, or `cancel` to abort.');
    message.channel?.send({ embeds: [embed] });
  });

  console.log('[MUSIC] ✅ DisTube music system initialized');
};
