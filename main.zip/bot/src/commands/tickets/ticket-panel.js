const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createTicketPanel } = require('../../systems/ticketSystem');
const { Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-panel')
    .setDescription('🎫 Create a ticket panel in this channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(o =>
      o.setName('channel')
        .setDescription('Channel to send the panel to (defaults to current)')
        .setRequired(false)
    ),
  cooldown: 10,
  execute: async (interaction, client) => {
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    await interaction.deferReply({ ephemeral: true });
    await createTicketPanel(channel, client);
    await interaction.editReply({ content: `${Emojis.SUCCESS} Ticket panel created in ${channel}!` });
  },
};
