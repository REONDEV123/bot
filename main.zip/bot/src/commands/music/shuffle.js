const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder().setName('shuffle').setDescription('🔀 Shuffle the queue'),
  cooldown: 3,
  execute: async (interaction, client) => {
    const queue = client.distube.getQueue(interaction.guild);
    if (!queue || queue.songs.length < 2) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Not enough songs to shuffle!`)], ephemeral: true });
    queue.shuffle();
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.SUCCESS).setDescription(`${Emojis.SHUFFLE} Queue shuffled! (${queue.songs.length} songs)`)] });
  },
};
