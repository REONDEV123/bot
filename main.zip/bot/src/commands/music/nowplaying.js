const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder().setName('nowplaying').setDescription('🎵 View the currently playing song'),
  cooldown: 3,
  execute: async (interaction, client) => {
    const queue = client.distube.getQueue(interaction.guild);
    if (!queue) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Nothing is playing!`)], ephemeral: true });

    const song      = queue.songs[0];
    const current   = queue.currentTime;
    const duration  = song.duration;
    const progress  = Math.floor((current / duration) * 20);
    const bar       = '▓'.repeat(progress) + '░'.repeat(20 - progress);

    const embed = new EmbedBuilder()
      .setColor(Colors.MUSIC)
      .setTitle(`${Emojis.MUSIC} Now Playing`)
      .setDescription(`**[${song.name}](${song.url})**`)
      .setThumbnail(song.thumbnail)
      .addFields(
        { name: '⏱️ Progress', value: `\`${bar}\`\n\`${queue.formattedCurrentTime} / ${song.formattedDuration}\``, inline: false },
        { name: '🎤 Requested By', value: `${song.user}`, inline: true },
        { name: '🔊 Volume',       value: `${queue.volume}%`, inline: true },
        { name: '🔁 Loop',         value: queue.repeatMode === 0 ? 'Off' : queue.repeatMode === 1 ? 'Song' : 'Queue', inline: true },
        { name: '📃 Queue',        value: `${queue.songs.length} song(s)`, inline: true },
        { name: '🔀 Autoplay',     value: queue.autoplay ? 'On' : 'Off', inline: true },
      )
      .setFooter({ text: 'Feathernodes Help | Credit: reondev', iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
