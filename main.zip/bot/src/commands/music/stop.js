const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder().setName('stop').setDescription('⏹️ Stop music and clear the queue'),
  cooldown: 3,
  execute: async (interaction, client) => {
    const queue = client.distube.getQueue(interaction.guild);
    if (!queue) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} No music is playing!`)], ephemeral: true });
    queue.stop();
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.SUCCESS).setDescription(`${Emojis.STOP} Music stopped and queue cleared.`)] });
  },
};
