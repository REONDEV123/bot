const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('search')
    .setDescription('🔍 Search for a song to play')
    .addStringOption(o => o.setName('query').setDescription('Song to search for').setRequired(true)),
  cooldown: 5,
  execute: async (interaction, client) => {
    const query  = interaction.options.getString('query');
    const vc     = interaction.member.voice.channel;

    if (!vc) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Join a voice channel first!`)], ephemeral: true });

    await interaction.deferReply();

    try {
      const results = await client.distube.search(query, { limit: 10, safeSearch: false });

      if (!results.length) {
        return interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} No results found for: \`${query}\``)] });
      }

      const list = results.map((s, i) => `**${i + 1}.** [${s.name}](${s.url}) \`${s.formattedDuration}\``).join('\n');

      const embed = new EmbedBuilder()
        .setColor(Colors.MUSIC)
        .setTitle(`${Emojis.MUSIC} Search Results for: ${query}`)
        .setDescription(`${list}\n\nType the number to play, or \`cancel\` to abort.`)
        .setFooter({ text: 'Feathernodes Help | Credit: reondev', iconURL: client.user.displayAvatarURL() });

      await interaction.editReply({ embeds: [embed] });

      // Wait for number response
      const filter   = m => m.author.id === interaction.user.id && (m.content === 'cancel' || (!isNaN(m.content) && +m.content >= 1 && +m.content <= results.length));
      const collector = interaction.channel.createMessageCollector({ filter, time: 30_000, max: 1 });

      collector.on('collect', async m => {
        if (m.content.toLowerCase() === 'cancel') {
          await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Search cancelled.`)], });
        } else {
          const picked = results[parseInt(m.content) - 1];
          await client.distube.play(vc, picked.url, { member: interaction.member, textChannel: interaction.channel });
        }
        m.delete().catch(() => {});
      });

      collector.on('end', (col, reason) => {
        if (reason === 'time') {
          interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Search timed out.`)] }).catch(() => {});
        }
      });
    } catch (err) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Error: ${err.message}`)] });
    }
  },
};
