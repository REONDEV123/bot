const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder().setName('resume').setDescription('▶️ Resume paused music'),
  cooldown: 2,
  execute: async (interaction, client) => {
    const queue = client.distube.getQueue(interaction.guild);
    if (!queue) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Nothing is playing!`)], ephemeral: true });
    if (!queue.paused) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.WARNING).setDescription(`${Emojis.WARNING} Music is not paused!`)], ephemeral: true });
    queue.resume();
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.SUCCESS).setDescription(`${Emojis.PLAY} Resumed: **${queue.songs[0].name}**`)] });
  },
};
