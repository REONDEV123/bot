const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('skip')
    .setDescription('⏭️ Skip the current song')
    .addIntegerOption(o => o.setName('amount').setDescription('Number of songs to skip').setRequired(false).setMinValue(1).setMaxValue(99)),
  cooldown: 2,
  execute: async (interaction, client) => {
    const queue = client.distube.getQueue(interaction.guild);
    if (!queue) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} No music is playing!`)], ephemeral: true });
    if (!interaction.member.voice.channelId) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Join a voice channel first!`)], ephemeral: true });

    const amount = interaction.options.getInteger('amount') || 1;
    const song   = queue.songs[0];

    try {
      if (amount > 1) {
        queue.songs.splice(1, amount - 1);
      }
      await queue.skip();
      await interaction.reply({
        embeds: [new EmbedBuilder().setColor(Colors.SUCCESS).setDescription(`${Emojis.SKIP} Skipped **${song.name}**${amount > 1 ? ` (+${amount - 1} more)` : ''}`)],
      });
    } catch (err) {
      await interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} ${err.message}`)], ephemeral: true });
    }
  },
};
