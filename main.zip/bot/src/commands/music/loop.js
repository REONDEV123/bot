const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('🔁 Set loop mode')
    .addStringOption(o =>
      o.setName('mode')
        .setDescription('Loop mode')
        .setRequired(true)
        .addChoices(
          { name: '❌ Off',      value: '0' },
          { name: '🔂 Song',    value: '1' },
          { name: '🔁 Queue',   value: '2' },
        )
    ),
  cooldown: 2,
  execute: async (interaction, client) => {
    const queue = client.distube.getQueue(interaction.guild);
    if (!queue) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Nothing is playing!`)], ephemeral: true });
    const mode   = parseInt(interaction.options.getString('mode'));
    const labels = ['Off', 'Song', 'Queue'];
    queue.setRepeatMode(mode);
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.SUCCESS).setDescription(`${Emojis.LOOP} Loop mode set to: **${labels[mode]}**`)] });
  },
};
