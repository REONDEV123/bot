const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('🎵 Play a song or playlist')
    .addStringOption(o =>
      o.setName('query')
        .setDescription('Song name, URL (YouTube, Spotify, SoundCloud)')
        .setRequired(true)
    ),
  cooldown: 3,
  execute: async (interaction, client) => {
    const query  = interaction.options.getString('query');
    const member = interaction.member;
    const vc     = member.voice.channel;

    if (!vc) {
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} You must be in a voice channel!`)],
        ephemeral: true,
      });
    }

    if (interaction.guild.members.me.voice.channelId && interaction.guild.members.me.voice.channelId !== vc.id) {
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} I'm already in another voice channel!`)],
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    try {
      await client.distube.play(vc, query, {
        member,
        textChannel: interaction.channel,
        interaction,
      });

      // Reply is handled by distube events
      const embed = new EmbedBuilder()
        .setColor(Colors.MUSIC)
        .setDescription(`${Emojis.LOADING} Processing: \`${query}\`...`);

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      await interaction.editReply({
        embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Error: ${err.message}`)],
      });
    }
  },
};
