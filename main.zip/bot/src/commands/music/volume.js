const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('🔊 Set the music volume')
    .addIntegerOption(o => o.setName('level').setDescription('Volume level (1-200)').setRequired(true).setMinValue(1).setMaxValue(200)),
  cooldown: 2,
  execute: async (interaction, client) => {
    const queue = client.distube.getQueue(interaction.guild);
    if (!queue) return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Nothing is playing!`)], ephemeral: true });
    const vol = interaction.options.getInteger('level');
    queue.setVolume(vol);
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.SUCCESS).setDescription(`${Emojis.VOLUME} Volume set to **${vol}%**`)] });
  },
};
