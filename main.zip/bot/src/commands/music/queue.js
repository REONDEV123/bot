const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('📃 View the music queue')
    .addIntegerOption(o => o.setName('page').setDescription('Page number').setRequired(false).setMinValue(1)),
  cooldown: 3,
  execute: async (interaction, client) => {
    const queue = client.distube.getQueue(interaction.guild);
    if (!queue || !queue.songs.length) {
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setDescription(`${Emojis.ERROR} Queue is empty!`)], ephemeral: true });
    }

    const page     = interaction.options.getInteger('page') || 1;
    const perPage  = 10;
    const start    = (page - 1) * perPage;
    const end      = start + perPage;
    const songs    = queue.songs.slice(start, end);
    const maxPages = Math.ceil(queue.songs.length / perPage);

    const list = songs.map((s, i) => {
      const num = start + i;
      return `${num === 0 ? '▶️ **Now Playing**' : `**${num}.**`} [${s.name}](${s.url}) \`${s.formattedDuration}\` | <@${s.user?.id || 'Unknown'}>`;
    }).join('\n');

    const totalDuration = queue.formattedDuration;

    const embed = new EmbedBuilder()
      .setColor(Colors.MUSIC)
      .setTitle(`${Emojis.QUEUE} Queue — ${queue.songs.length} song(s)`)
      .setDescription(list || 'No songs on this page.')
      .addFields(
        { name: '⏱️ Total Duration', value: `\`${totalDuration}\``, inline: true },
        { name: '🔁 Loop Mode',      value: `\`${queue.repeatMode === 0 ? 'Off' : queue.repeatMode === 1 ? 'Song' : 'Queue'}\``, inline: true },
        { name: '🔊 Volume',         value: `\`${queue.volume}%\``, inline: true },
      )
      .setFooter({ text: `Page ${page}/${maxPages} | Feathernodes Help | Credit: reondev`, iconURL: client.user.displayAvatarURL() });

    await interaction.reply({ embeds: [embed] });
  },
};
