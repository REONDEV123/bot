const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('📊 View information about this server'),
  cooldown: 10,
  execute: async (interaction, client) => {
    const { guild } = interaction;
    await guild.fetch();

    const textChannels   = guild.channels.cache.filter(c => c.type === ChannelType.GuildText).size;
    const voiceChannels  = guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size;
    const categories     = guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory).size;
    const bots           = guild.members.cache.filter(m => m.user.bot).size;
    const humans         = guild.memberCount - bots;

    const verificationLevels = { 0: 'None', 1: 'Low', 2: 'Medium', 3: 'High', 4: 'Highest' };

    const embed = new EmbedBuilder()
      .setColor(Colors.INFO)
      .setTitle(`${Emojis.STATS} ${guild.name} — Server Info`)
      .setThumbnail(guild.iconURL({ size: 256 }))
      .addFields(
        { name: '🆔 Server ID',       value: `\`${guild.id}\``,                  inline: true },
        { name: '👑 Owner',           value: `<@${guild.ownerId}>`,              inline: true },
        { name: '📅 Created',         value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
        { name: '👥 Members',         value: `\`${guild.memberCount}\` total\n\`${humans}\` humans\n\`${bots}\` bots`, inline: true },
        { name: '📺 Channels',        value: `\`${textChannels}\` text\n\`${voiceChannels}\` voice\n\`${categories}\` categories`, inline: true },
        { name: '🎭 Roles',           value: `\`${guild.roles.cache.size}\``,     inline: true },
        { name: '😀 Emojis',          value: `\`${guild.emojis.cache.size}\``,   inline: true },
        { name: '🔒 Verification',    value: `\`${verificationLevels[guild.verificationLevel]}\``, inline: true },
        { name: '💎 Boost Level',     value: `\`Tier ${guild.premiumTier}\``,     inline: true },
        { name: '🚀 Boosts',          value: `\`${guild.premiumSubscriptionCount || 0}\``, inline: true },
        { name: '🌍 Region',          value: `\`Auto\``,                          inline: true },
        { name: '🔗 Vanity URL',      value: guild.vanityURLCode ? `\`discord.gg/${guild.vanityURLCode}\`` : '`None`', inline: true },
      )
      .setImage(guild.bannerURL({ size: 1024 }) || null)
      .setFooter({ text: 'Feathernodes Help | Credit: reondev', iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
