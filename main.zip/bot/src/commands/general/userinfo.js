const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('👤 View information about a user')
    .addUserOption(o => o.setName('user').setDescription('The user to get info about').setRequired(false)),
  cooldown: 5,
  execute: async (interaction, client) => {
    const target = interaction.options.getMember('user') || interaction.member;
    const user   = target.user;

    const roles = target.roles.cache
      .filter(r => r.id !== interaction.guild.id)
      .sort((a, b) => b.position - a.position)
      .map(r => `<@&${r.id}>`)
      .slice(0, 10)
      .join(', ') || 'None';

    const badges = user.flags?.toArray().join(', ') || 'None';

    const embed = new EmbedBuilder()
      .setColor(target.displayColor || Colors.INFO)
      .setTitle(`${Emojis.INFO} ${user.tag} — User Info`)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: '🆔 User ID',      value: `\`${user.id}\``,                   inline: true },
        { name: '🤖 Bot?',         value: `\`${user.bot ? 'Yes' : 'No'}\``,   inline: true },
        { name: '📛 Nickname',     value: `\`${target.nickname || 'None'}\``, inline: true },
        { name: '📅 Acc. Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: '📅 Joined Server',value: `<t:${Math.floor(target.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: '🎭 Highest Role', value: `${target.roles.highest}`,          inline: true },
        { name: `🎭 Roles (${target.roles.cache.size - 1})`, value: roles,    inline: false },
        { name: '🏅 Badges',       value: badges,                             inline: false },
      )
      .setFooter({ text: 'Feathernodes Help | Credit: reondev', iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
