const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription(`${Emojis.PING} Check the bot's latency`),
  cooldown: 5,
  execute: async (interaction, client) => {
    const sent = await interaction.reply({ content: `${Emojis.LOADING} Measuring ping...`, fetchReply: true });
    const roundtrip = sent.createdTimestamp - interaction.createdTimestamp;

    const embed = new EmbedBuilder()
      .setColor(Colors.SUCCESS)
      .setTitle(`${Emojis.PING} Pong!`)
      .addFields(
        { name: '🌐 WebSocket Latency', value: `\`${client.ws.ping}ms\``,   inline: true },
        { name: '⏱️ Round-trip',        value: `\`${roundtrip}ms\``,         inline: true },
        { name: '🤖 Bot Status',        value: '`Online ✅`',                inline: true },
      )
      .setFooter({ text: 'Feathernodes Help | Credit: reondev', iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.editReply({ content: null, embeds: [embed] });
  },
};
