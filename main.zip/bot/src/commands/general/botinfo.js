const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');
const os = require('os');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('ℹ️ View information about Feathernodes Help Bot'),
  cooldown: 10,
  execute: async (interaction, client) => {
    const uptime    = process.uptime();
    const hours     = Math.floor(uptime / 3600);
    const minutes   = Math.floor((uptime % 3600) / 60);
    const seconds   = Math.floor(uptime % 60);
    const uptimeStr = `${hours}h ${minutes}m ${seconds}s`;

    const memUsed = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const memTotal = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);

    const embed = new EmbedBuilder()
      .setColor(Colors.PRIMARY)
      .setTitle(`${Emojis.FEATHER} Feathernodes Help — Bot Information`)
      .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: '🤖 Bot Name',       value: `\`${client.user.tag}\``,                    inline: true },
        { name: '🆔 Bot ID',         value: `\`${client.user.id}\``,                     inline: true },
        { name: '👑 Made By',        value: '`Feathernodes Team`',                       inline: true },
        { name: '⭐ Credit',         value: '`reondev`',                                  inline: true },
        { name: '📅 Created',        value: `<t:${Math.floor(client.user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: '🌐 Servers',        value: `\`${client.guilds.cache.size}\``,            inline: true },
        { name: '👥 Users',          value: `\`${client.users.cache.size}\``,             inline: true },
        { name: '⚡ Ping',           value: `\`${client.ws.ping}ms\``,                   inline: true },
        { name: '⏱️ Uptime',         value: `\`${uptimeStr}\``,                           inline: true },
        { name: '🧠 Memory',         value: `\`${memUsed} MB / ${memTotal} GB\``,        inline: true },
        { name: '📦 discord.js',     value: `\`v${require('discord.js').version}\``,     inline: true },
        { name: '⚙️ Node.js',        value: `\`${process.version}\``,                    inline: true },
        { name: '🎫 Ticket System',  value: '`R.O.T.I Style ✅`',                        inline: true },
        { name: '🛡️ AntiNuke',      value: '`Wick Style ✅`',                            inline: true },
        { name: '🎵 Music',          value: '`DisTube ✅`',                               inline: true },
      )
      .setFooter({ text: 'Feathernodes Help | Made by Feathernodes Team | Credit: reondev', iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
