/**
 * Help Command - Feathernodes Help Bot
 */

const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

const CATEGORIES = {
  '🎫 Tickets':    { desc: 'Advanced ticket management system',     cmds: ['/ticket-panel', '/ticket-close', '/ticket-add', '/ticket-claim', '/ticket-transcript'] },
  '🛡️ AntiNuke':  { desc: 'Server protection & security',           cmds: ['/antinuke setup', '/antinuke whitelist', '/antinuke status', '/antinuke toggle'] },
  '🎵 Music':      { desc: 'High-quality music playback',            cmds: ['/play', '/skip', '/stop', '/queue', '/pause', '/resume', '/volume', '/nowplaying', '/shuffle', '/loop', '/search', '/lyrics'] },
  '🔨 Moderation': { desc: 'Server moderation tools',               cmds: ['/ban', '/kick', '/mute', '/unmute', '/warn', '/warnings', '/clear', '/lock', '/unlock', '/slowmode'] },
  '📊 Utility':    { desc: 'Server & user utilities',                cmds: ['/userinfo', '/serverinfo', '/botinfo', '/avatar', '/ping', '/uptime', '/stats'] },
  '⚙️ Config':     { desc: 'Bot configuration',                      cmds: ['/setprefix', '/setlogs', '/setticket', '/setup'] },
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('📚 View all Feathernodes Help Bot commands')
    .addStringOption(o =>
      o.setName('category')
        .setDescription('Specific category to view')
        .setRequired(false)
        .addChoices(
          { name: '🎫 Tickets',    value: 'tickets'    },
          { name: '🛡️ AntiNuke',  value: 'antinuke'   },
          { name: '🎵 Music',      value: 'music'      },
          { name: '🔨 Moderation', value: 'moderation' },
          { name: '📊 Utility',    value: 'utility'    },
        )
    ),
  cooldown: 5,
  execute: async (interaction, client) => {
    const cat = interaction.options.getString('category');

    const mainEmbed = new EmbedBuilder()
      .setColor(Colors.PRIMARY)
      .setTitle(`${Emojis.FEATHER} Feathernodes Help — Command Center`)
      .setThumbnail(client.user.displayAvatarURL())
      .setDescription(
        `**Welcome to Feathernodes Help Bot!**\n` +
        `The ultimate all-in-one Discord bot for your server.\n\n` +
        `**Made by:** Feathernodes Team\n` +
        `**Credit:** reondev\n` +
        `**Website:** [feathernodes.xyz](https://feathernodes.xyz)\n\n` +
        `Select a category below or use the dropdown to explore commands.`
      )
      .addFields(
        Object.entries(CATEGORIES).map(([name, { desc, cmds }]) => ({
          name:   `${name} (${cmds.length} commands)`,
          value:  desc,
          inline: true,
        }))
      )
      .addFields({ name: '\u200b', value: '\u200b', inline: false })
      .addFields(
        { name: '📈 Stats',       value: `**${client.guilds.cache.size}** servers\n**${client.users.cache.size}** users`, inline: true },
        { name: '⚡ Ping',        value: `${client.ws.ping}ms`, inline: true },
        { name: '🔗 Invite',      value: `[Click Here](https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot+applications.commands)`, inline: true },
      )
      .setFooter({ text: `Feathernodes Help | Made by Feathernodes Team | Credit: reondev`, iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('Invite Bot')
        .setStyle(ButtonStyle.Link)
        .setEmoji('🔗')
        .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot+applications.commands`),
      new ButtonBuilder()
        .setLabel('Website')
        .setStyle(ButtonStyle.Link)
        .setEmoji('🌐')
        .setURL('https://feathernodes.xyz'),
      new ButtonBuilder()
        .setLabel('Support Server')
        .setStyle(ButtonStyle.Link)
        .setEmoji('💬')
        .setURL('https://discord.gg/feathernodes'),
    );

    await interaction.reply({ embeds: [mainEmbed], components: [buttons] });
  },
};
