const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('🗑️ Bulk delete messages')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(o => o.setName('amount').setDescription('Number of messages to delete (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('user').setDescription('Only delete messages from this user').setRequired(false)),
  cooldown: 5,
  execute: async (interaction, client) => {
    const amount = interaction.options.getInteger('amount');
    const user   = interaction.options.getUser('user');

    await interaction.deferReply({ ephemeral: true });

    try {
      let messages = await interaction.channel.messages.fetch({ limit: 100 });
      if (user) messages = messages.filter(m => m.author.id === user.id);
      messages = messages.filter(m => Date.now() - m.createdTimestamp < 14 * 24 * 60 * 60 * 1000);
      const toDelete = [...messages.values()].slice(0, amount);

      const deleted = await interaction.channel.bulkDelete(toDelete, true);

      await interaction.editReply({
        embeds: [new EmbedBuilder().setColor(Colors.SUCCESS).setDescription(`${Emojis.DELETE} Deleted **${deleted.size}** message(s)${user ? ` from ${user.tag}` : ''}.`)],
      });
    } catch (err) {
      await interaction.editReply({ content: `${Emojis.ERROR} Error: ${err.message}` });
    }
  },
};
