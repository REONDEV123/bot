const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');
const ms = require('ms');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('🔇 Timeout (mute) a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to mute').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 10m, 1h, 1d)').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),
  cooldown: 3,
  execute: async (interaction, client) => {
    const target   = interaction.options.getMember('user');
    const duration = interaction.options.getString('duration');
    const reason   = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.reply({ content: `${Emojis.ERROR} User not found.`, ephemeral: true });

    const msTime = ms(duration);
    if (!msTime || msTime > 2419200000) {
      return interaction.reply({ content: `${Emojis.ERROR} Invalid duration! Max is 28 days. Examples: \`10m\`, \`1h\`, \`1d\``, ephemeral: true });
    }

    try {
      await target.timeout(msTime, `[${interaction.user.tag}] ${reason}`);
    } catch {
      return interaction.reply({ content: `${Emojis.ERROR} Failed to timeout this user.`, ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(Colors.WARNING)
      .setTitle(`${Emojis.MUTE} Member Muted`)
      .addFields(
        { name: '👤 User',       value: `${target.user.tag}`, inline: true },
        { name: '⏱️ Duration',   value: duration,             inline: true },
        { name: '🔨 Moderator', value: interaction.user.tag,  inline: true },
        { name: '📝 Reason',    value: reason,                inline: false },
      )
      .setFooter({ text: 'Feathernodes Help | Credit: reondev' }).setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
