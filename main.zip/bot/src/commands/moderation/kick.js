const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('👢 Kick a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for kick').setRequired(false)),
  cooldown: 3,
  execute: async (interaction, client) => {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.reply({ content: `${Emojis.ERROR} User not found.`, ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ content: `${Emojis.ERROR} You cannot kick yourself.`, ephemeral: true });
    if (!target.kickable) return interaction.reply({ content: `${Emojis.ERROR} I cannot kick this user.`, ephemeral: true });

    try { await target.user.send({ embeds: [new EmbedBuilder().setColor(Colors.WARNING).setTitle(`${Emojis.KICK} You have been kicked`).setDescription(`**Server:** ${interaction.guild.name}\n**Reason:** ${reason}`)] }); } catch {}

    await target.kick(`[${interaction.user.tag}] ${reason}`);

    const embed = new EmbedBuilder()
      .setColor(Colors.WARNING)
      .setTitle(`${Emojis.KICK} Member Kicked`)
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: '👤 User',       value: `${target.user.tag} (\`${target.user.id}\`)`, inline: true },
        { name: '🔨 Moderator', value: interaction.user.tag, inline: true },
        { name: '📝 Reason',    value: reason, inline: false },
      )
      .setFooter({ text: 'Feathernodes Help | Credit: reondev' }).setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
