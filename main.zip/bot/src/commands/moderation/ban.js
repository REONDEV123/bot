const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('🔨 Ban a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for ban').setRequired(false))
    .addIntegerOption(o => o.setName('days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7).setRequired(false)),
  cooldown: 3,
  execute: async (interaction, client) => {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const days   = interaction.options.getInteger('days') || 0;

    if (!target) return interaction.reply({ content: `${Emojis.ERROR} User not found.`, ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ content: `${Emojis.ERROR} You cannot ban yourself.`, ephemeral: true });
    if (target.id === client.user.id) return interaction.reply({ content: `${Emojis.ERROR} I cannot ban myself.`, ephemeral: true });
    if (!target.bannable) return interaction.reply({ content: `${Emojis.ERROR} I cannot ban this user (missing permissions or hierarchy).`, ephemeral: true });

    // DM the user
    try {
      await target.user.send({ embeds: [new EmbedBuilder().setColor(Colors.ERROR).setTitle(`${Emojis.BAN} You have been banned`).setDescription(`**Server:** ${interaction.guild.name}\n**Reason:** ${reason}\n**Moderator:** ${interaction.user.tag}`)] });
    } catch {}

    await target.ban({ reason: `[${interaction.user.tag}] ${reason}`, deleteMessageSeconds: days * 86400 });

    const embed = new EmbedBuilder()
      .setColor(Colors.ERROR)
      .setTitle(`${Emojis.BAN} Member Banned`)
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: '👤 User',       value: `${target.user.tag} (\`${target.user.id}\`)`, inline: true },
        { name: '🔨 Moderator', value: `${interaction.user.tag}`, inline: true },
        { name: '📝 Reason',    value: reason, inline: false },
        { name: '🗑️ Msg Delete', value: `${days} day(s)`, inline: true },
      )
      .setFooter({ text: 'Feathernodes Help | Credit: reondev', iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
