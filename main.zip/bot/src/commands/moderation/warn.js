const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');

// Simple in-memory warning store (use DB for production)
const warnings = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('⚠️ Warn a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for warning').setRequired(true)),
  cooldown: 3,
  execute: async (interaction, client) => {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');

    if (!target) return interaction.reply({ content: `${Emojis.ERROR} User not found.`, ephemeral: true });
    if (target.user.bot) return interaction.reply({ content: `${Emojis.ERROR} Cannot warn bots.`, ephemeral: true });

    const key = `${interaction.guild.id}-${target.id}`;
    if (!warnings.has(key)) warnings.set(key, []);
    const userWarns = warnings.get(key);
    userWarns.push({ reason, by: interaction.user.id, at: new Date() });

    // DM the warned user
    try {
      await target.user.send({
        embeds: [new EmbedBuilder().setColor(Colors.WARNING).setTitle(`${Emojis.WARN} You have been warned`).setDescription(`**Server:** ${interaction.guild.name}\n**Reason:** ${reason}\n**Warning #${userWarns.length}**`)],
      });
    } catch {}

    const embed = new EmbedBuilder()
      .setColor(Colors.WARNING)
      .setTitle(`${Emojis.WARN} Member Warned`)
      .addFields(
        { name: '👤 User',        value: `${target.user.tag}`,     inline: true },
        { name: '🔨 Moderator',  value: interaction.user.tag,     inline: true },
        { name: '#️⃣ Warning #',  value: `#${userWarns.length}`,   inline: true },
        { name: '📝 Reason',     value: reason,                   inline: false },
      )
      .setFooter({ text: 'Feathernodes Help | Credit: reondev' }).setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },

  // Export warnings for /warnings command
  warnings,
};
