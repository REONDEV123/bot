/**
 * AntiNuke Command - Feathernodes Help Bot
 * Configure and manage the AntiNuke protection system
 */

const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} = require('discord.js');
const { Colors, Emojis, AntiNukeThresholds } = require('../../utils/constants');
const { isOwner } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antinuke')
    .setDescription('🛡️ Manage the AntiNuke protection system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('View the current AntiNuke configuration')
    )
    .addSubcommand(sub =>
      sub.setName('setup')
        .setDescription('Configure AntiNuke settings')
        .addChannelOption(o =>
          o.setName('log_channel')
            .setDescription('Channel to send AntiNuke alerts to')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('toggle')
        .setDescription('Enable or disable AntiNuke')
        .addBooleanOption(o =>
          o.setName('enabled')
            .setDescription('Enable or disable AntiNuke protection')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('whitelist')
        .setDescription('Manage the AntiNuke whitelist')
        .addStringOption(o =>
          o.setName('action')
            .setDescription('Add or remove from whitelist')
            .setRequired(true)
            .addChoices(
              { name: 'Add',    value: 'add'    },
              { name: 'Remove', value: 'remove' },
              { name: 'List',   value: 'list'   },
            )
        )
        .addUserOption(o =>
          o.setName('user')
            .setDescription('User to add/remove from whitelist')
            .setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub.setName('thresholds')
        .setDescription('View detection thresholds')
    ),

  cooldown: 5,
  execute: async (interaction, client) => {
    const sub = interaction.options.getSubcommand();

    if (!isOwner(interaction.user.id) && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: `${Emojis.ERROR} Only server admins and bot owners can use AntiNuke commands.`, ephemeral: true });
    }

    if (sub === 'status') {
      const enabled    = process.env.ANTINUKE_ENABLED !== 'false';
      const whitelist  = (process.env.ANTINUKE_WHITELIST || '').split(',').filter(Boolean);
      const logChannel = process.env.ANTINUKE_LOG_CHANNEL || 'antinuke-logs';

      const embed = new EmbedBuilder()
        .setColor(enabled ? Colors.SUCCESS : Colors.ERROR)
        .setTitle(`${Emojis.SHIELD} AntiNuke Status`)
        .setDescription(`AntiNuke is currently **${enabled ? '🟢 ENABLED' : '🔴 DISABLED'}**`)
        .addFields(
          { name: '📋 Log Channel',     value: `\`${logChannel}\``,                              inline: true },
          { name: '👥 Whitelist Count', value: `\`${whitelist.length} users\``,                  inline: true },
          { name: '⚡ Status',          value: enabled ? '`Active`' : '`Disabled`',              inline: true },
          { name: '\u200b', value: '**Detection Thresholds:**', inline: false },
          { name: '🔨 Mass Ban',        value: `\`${AntiNukeThresholds.BAN_THRESHOLD} bans / 10s\``,            inline: true },
          { name: '👢 Mass Kick',       value: `\`${AntiNukeThresholds.KICK_THRESHOLD} kicks / 10s\``,          inline: true },
          { name: '🗑️ Channel Delete', value: `\`${AntiNukeThresholds.CHANNEL_DELETE_THRESHOLD} dels / 10s\``, inline: true },
          { name: '🎭 Role Delete',     value: `\`${AntiNukeThresholds.ROLE_DELETE_THRESHOLD} dels / 10s\``,    inline: true },
          { name: '🔗 Webhook Abuse',   value: `\`${AntiNukeThresholds.WEBHOOK_THRESHOLD} hooks / 10s\``,      inline: true },
          { name: '🤖 Bot Add',         value: '`Auto-kick + Alert`',                             inline: true },
          { name: '\u200b', value: '**Protected Actions:**', inline: false },
          { name: '✅ Protected',       value: [
            '• Mass Ban Detection',
            '• Mass Kick Detection',
            '• Mass Channel Delete',
            '• Mass Role Delete',
            '• Dangerous Permission Grant',
            '• Webhook Spam Protection',
            '• Unauthorized Bot Addition',
            '• Server Vandalism Alert',
          ].join('\n'), inline: false },
        )
        .setFooter({ text: 'Feathernodes Help AntiNuke | Credit: reondev', iconURL: client.user.displayAvatarURL() })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'setup') {
      const logChannel = interaction.options.getChannel('log_channel');

      const embed = new EmbedBuilder()
        .setColor(Colors.SUCCESS)
        .setTitle(`${Emojis.SUCCESS} AntiNuke Configured`)
        .setDescription(
          `AntiNuke has been configured!\n\n` +
          `**Log Channel:** ${logChannel}\n\n` +
          `> ⚠️ **Important:** Update your \`.env\` file:\n` +
          `> \`ANTINUKE_LOG_CHANNEL=${logChannel.id}\`\n` +
          `> \`ANTINUKE_ENABLED=true\`\n\n` +
          `**Make sure the bot has these permissions:**\n` +
          `• View Audit Log\n• Ban Members\n• Kick Members\n• Manage Roles\n• Administrator (recommended)`
        )
        .setFooter({ text: 'Feathernodes Help AntiNuke | Credit: reondev' });

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'toggle') {
      const enabled = interaction.options.getBoolean('enabled');
      const embed   = new EmbedBuilder()
        .setColor(enabled ? Colors.SUCCESS : Colors.ERROR)
        .setTitle(`${Emojis.SHIELD} AntiNuke ${enabled ? 'Enabled' : 'Disabled'}`)
        .setDescription(
          `AntiNuke has been **${enabled ? '🟢 Enabled' : '🔴 Disabled'}**.\n\n` +
          `> Update \`ANTINUKE_ENABLED=${enabled}\` in your \`.env\` file and restart the bot.`
        );
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'whitelist') {
      const action  = interaction.options.getString('action');
      const user    = interaction.options.getUser('user');
      const whitelist = (process.env.ANTINUKE_WHITELIST || '').split(',').filter(Boolean);

      if (action === 'list') {
        const embed = new EmbedBuilder()
          .setColor(Colors.INFO)
          .setTitle(`${Emojis.SHIELD} AntiNuke Whitelist`)
          .setDescription(
            whitelist.length
              ? whitelist.map((id, i) => `**${i + 1}.** <@${id}> (\`${id}\`)`).join('\n')
              : 'No users whitelisted. Only the bot owner is always exempt.'
          );
        return interaction.reply({ embeds: [embed] });
      }

      if (!user) return interaction.reply({ content: `${Emojis.ERROR} Please specify a user.`, ephemeral: true });

      const embed = new EmbedBuilder()
        .setColor(Colors.INFO)
        .setTitle(`${Emojis.SHIELD} Whitelist Updated`)
        .setDescription(
          action === 'add'
            ? `${Emojis.SUCCESS} **${user.tag}** added to AntiNuke whitelist.\n> Update \`ANTINUKE_WHITELIST\` in \`.env\`.`
            : `${Emojis.SUCCESS} **${user.tag}** removed from AntiNuke whitelist.`
        );

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'thresholds') {
      const embed = new EmbedBuilder()
        .setColor(Colors.INFO)
        .setTitle(`${Emojis.SHIELD} AntiNuke Detection Thresholds`)
        .setDescription('These thresholds define how many actions within **10 seconds** trigger protection:')
        .addFields(
          { name: '🔨 Mass Ban',      value: `\`${AntiNukeThresholds.BAN_THRESHOLD}+ bans\``,           inline: true },
          { name: '👢 Mass Kick',     value: `\`${AntiNukeThresholds.KICK_THRESHOLD}+ kicks\``,         inline: true },
          { name: '🗑️ Chan. Delete', value: `\`${AntiNukeThresholds.CHANNEL_DELETE_THRESHOLD}+ dels\``, inline: true },
          { name: '🎭 Role Delete',   value: `\`${AntiNukeThresholds.ROLE_DELETE_THRESHOLD}+ dels\``,   inline: true },
          { name: '🔗 Webhooks',      value: `\`${AntiNukeThresholds.WEBHOOK_THRESHOLD}+ hooks\``,      inline: true },
          { name: '⏱️ Time Window',   value: `\`${AntiNukeThresholds.TIME_WINDOW / 1000} seconds\``,   inline: true },
        )
        .setFooter({ text: 'Feathernodes Help | Credit: reondev' });

      return interaction.reply({ embeds: [embed] });
    }
  },
};
