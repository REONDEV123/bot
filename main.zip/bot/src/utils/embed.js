/**
 * Embed Utilities - Feathernodes Help Bot
 * Pre-built embed templates
 */

const { EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('./constants');

const footer = (client) => ({
  text: `Feathernodes Help | Credit: reondev`,
  iconURL: client?.user?.displayAvatarURL() || undefined,
});

module.exports = {
  success: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.SUCCESS)
      .setTitle(`${Emojis.SUCCESS} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),

  error: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.ERROR)
      .setTitle(`${Emojis.ERROR} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),

  warning: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.WARNING)
      .setTitle(`${Emojis.WARNING} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),

  info: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.INFO)
      .setTitle(`${Emojis.INFO} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),

  ticket: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.TICKET)
      .setTitle(`${Emojis.TICKET} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),

  antinuke: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.ANTINUKE)
      .setTitle(`${Emojis.SHIELD} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),

  mod: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.MOD)
      .setTitle(`${Emojis.HAMMER} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),

  music: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.MUSIC)
      .setTitle(`${Emojis.MUSIC} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),

  log: (client, title, description) =>
    new EmbedBuilder()
      .setColor(Colors.LOG)
      .setTitle(`${Emojis.LOG} ${title}`)
      .setDescription(description)
      .setFooter(footer(client))
      .setTimestamp(),
};
