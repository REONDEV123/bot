/**
 * Permission Utilities - Feathernodes Help Bot
 */

const isOwner = (userId) => {
  const owners = (process.env.OWNER_IDS || '').split(',').map(id => id.trim());
  return owners.includes(userId);
};

const isAdmin = (member) =>
  member.permissions.has('Administrator') || isOwner(member.id);

const isMod = (member) =>
  member.permissions.has('ManageMessages') ||
  member.permissions.has('KickMembers') ||
  isAdmin(member);

const isSupport = (member, supportRoleId) => {
  if (isMod(member)) return true;
  if (supportRoleId && member.roles.cache.has(supportRoleId)) return true;
  return false;
};

const checkAntiNukeWhitelist = (userId) => {
  const whitelist = (process.env.ANTINUKE_WHITELIST || '').split(',').map(id => id.trim()).filter(Boolean);
  return isOwner(userId) || whitelist.includes(userId);
};

module.exports = { isOwner, isAdmin, isMod, isSupport, checkAntiNukeWhitelist };
