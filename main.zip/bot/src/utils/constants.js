/**
 * Constants - Feathernodes Help Bot
 * Colors, Emojis, and shared constants
 */

const Colors = {
  PRIMARY:  0x5865F2, // Discord Blurple
  SUCCESS:  0x57F287, // Green
  ERROR:    0xED4245, // Red
  WARNING:  0xFEE75C, // Yellow
  INFO:     0x5865F2, // Blue
  MUSIC:    0x9B59B6, // Purple
  TICKET:   0x3498DB, // Cyan Blue
  ANTINUKE: 0xFF0000, // Red Alert
  LOG:      0x2F3136, // Dark
  MOD:      0xE74C3C, // Moderation Red
  DEFAULT:  0x2B2D31, // Dark Gray
};

const Emojis = {
  SUCCESS:  '✅',
  ERROR:    '❌',
  WARNING:  '⚠️',
  INFO:     'ℹ️',
  MUSIC:    '🎵',
  TICKET:   '🎫',
  SHIELD:   '🛡️',
  HAMMER:   '🔨',
  LOCK:     '🔒',
  UNLOCK:   '🔓',
  STAR:     '⭐',
  CROWN:    '👑',
  FEATHER:  '🪶',
  LOADING:  '⏳',
  PING:     '🏓',
  STATS:    '📊',
  LOG:      '📋',
  MUSIC_NOTE: '🎶',
  SKIP:     '⏭️',
  PAUSE:    '⏸️',
  PLAY:     '▶️',
  STOP:     '⏹️',
  QUEUE:    '📃',
  VOLUME:   '🔊',
  LOOP:     '🔁',
  SHUFFLE:  '🔀',
  ANTINUKE: '🛡️',
  BAN:      '🔨',
  KICK:     '👢',
  MUTE:     '🔇',
  WARN:     '⚠️',
  DELETE:   '🗑️',
};

const AntiNukeActions = {
  MASS_BAN:       'MASS_BAN',
  MASS_KICK:      'MASS_KICK',
  MASS_CHANNEL_DELETE: 'MASS_CHANNEL_DELETE',
  MASS_ROLE_DELETE:    'MASS_ROLE_DELETE',
  MASS_WEBHOOK_CREATE: 'MASS_WEBHOOK_CREATE',
  BOT_ADD:             'BOT_ADD',
  GUILD_UPDATE:        'GUILD_UPDATE',
  MASS_MENTION:        'MASS_MENTION',
  DANGEROUS_PERMISSIONS: 'DANGEROUS_PERMISSIONS',
};

const AntiNukeThresholds = {
  BAN_THRESHOLD:            3, // bans within time window
  KICK_THRESHOLD:           3,
  CHANNEL_DELETE_THRESHOLD: 3,
  ROLE_DELETE_THRESHOLD:    3,
  WEBHOOK_THRESHOLD:        3,
  TIME_WINDOW:          10000, // 10 seconds
};

const TicketStatus = {
  OPEN:    'open',
  CLOSED:  'closed',
  CLAIMED: 'claimed',
};

const Permissions = {
  OWNER_ONLY: ['OWNER'],
  ADMIN_ONLY: ['Administrator'],
  MOD_ONLY:   ['ManageMessages', 'KickMembers'],
  SUPPORT:    ['ManageChannels'],
};

module.exports = { Colors, Emojis, AntiNukeActions, AntiNukeThresholds, TicketStatus, Permissions };
