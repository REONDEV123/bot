/**
 * Interaction Create Event - Feathernodes Help Bot
 * Handles slash commands, buttons, select menus, modals
 */

const { EmbedBuilder } = require('discord.js');
const { Colors, Emojis } = require('../../utils/constants');
const {
  openTicket,
  closeTicket,
  confirmClose,
  claimTicket,
  addUserToTicket,
  ticketData,
} = require('../../systems/ticketSystem');

module.exports = {
  name:    'interactionCreate',
  once:    false,
  execute: async (client, interaction) => {

    // ─── Slash Commands ─────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) {
        return interaction.reply({ content: `${Emojis.ERROR} Command not found.`, ephemeral: true });
      }

      // Cooldown
      const { cooldowns } = client;
      if (!cooldowns.has(command.data.name)) cooldowns.set(command.data.name, new Map());
      const now        = Date.now();
      const timestamps = cooldowns.get(command.data.name);
      const cooldown   = (command.cooldown || 3) * 1000;

      if (timestamps.has(interaction.user.id)) {
        const expiration = timestamps.get(interaction.user.id) + cooldown;
        if (now < expiration) {
          const left = ((expiration - now) / 1000).toFixed(1);
          return interaction.reply({
            content: `${Emojis.WARNING} Please wait **${left}s** before using \`/${command.data.name}\` again.`,
            ephemeral: true,
          });
        }
      }

      timestamps.set(interaction.user.id, now);
      setTimeout(() => timestamps.delete(interaction.user.id), cooldown);

      try {
        await command.execute(interaction, client);
      } catch (err) {
        console.error(`[CMD ERROR] /${command.data.name}:`, err);
        const errEmbed = new EmbedBuilder()
          .setColor(Colors.ERROR)
          .setTitle(`${Emojis.ERROR} Command Error`)
          .setDescription(`An error occurred while executing this command.\n\`\`\`${err.message}\`\`\``)
          .setFooter({ text: 'Feathernodes Help | Credit: reondev' });

        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [errEmbed], ephemeral: true }).catch(() => {});
        } else {
          await interaction.reply({ embeds: [errEmbed], ephemeral: true }).catch(() => {});
        }
      }
    }

    // ─── Button Interactions ─────────────────────────────────────
    else if (interaction.isButton()) {
      const { customId, guild, channel, member, user } = interaction;

      try {
        switch (customId) {
          case 'ticket_close':
            await closeTicket(interaction, client);
            break;

          case 'ticket_close_confirm':
            await confirmClose(interaction, client);
            break;

          case 'ticket_close_cancel':
            await interaction.update({ content: `${Emojis.SUCCESS} Close cancelled.`, embeds: [], components: [] });
            break;

          case 'ticket_claim':
            await claimTicket(interaction, client);
            break;

          case 'ticket_transcript': {
            const { generateTranscript } = require('../../systems/ticketSystem');
            const { AttachmentBuilder } = require('discord.js');
            const data = ticketData.get(channel.id);
            if (!data) {
              return interaction.reply({ content: `${Emojis.ERROR} Not a ticket channel.`, ephemeral: true });
            }
            await interaction.deferReply({ ephemeral: true });
            const html  = await generateTranscript(channel);
            const file  = new AttachmentBuilder(Buffer.from(html, 'utf-8'), { name: `transcript-${channel.name}.html` });
            await interaction.editReply({ content: `${Emojis.SUCCESS} Transcript generated!`, files: [file] });
            break;
          }

          case 'ticket_add_user':
            await addUserToTicket(interaction, client);
            break;

          default:
            break;
        }
      } catch (err) {
        console.error('[BUTTON ERROR]', err);
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: `${Emojis.ERROR} Button error: ${err.message}`, ephemeral: true }).catch(() => {});
        }
      }
    }

    // ─── Select Menu Interactions ─────────────────────────────────
    else if (interaction.isStringSelectMenu()) {
      const { customId, values } = interaction;

      if (customId === 'ticket_category_select') {
        await openTicket(interaction, client, values[0]);
      }
    }

    // ─── Modal Submissions ────────────────────────────────────────
    else if (interaction.isModalSubmit()) {
      const { customId, guild, channel } = interaction;

      if (customId === 'ticket_add_user_modal') {
        const userId = interaction.fields.getTextInputValue('user_id_input').trim();
        try {
          const targetUser = await client.users.fetch(userId);
          await channel.permissionOverwrites.edit(userId, {
            ViewChannel:      true,
            SendMessages:     true,
            ReadMessageHistory: true,
          });
          await interaction.reply({
            content: `${Emojis.SUCCESS} Added **${targetUser.tag}** to this ticket.`,
            ephemeral: true,
          });
        } catch {
          await interaction.reply({
            content: `${Emojis.ERROR} Invalid user ID or couldn't find user.`,
            ephemeral: true,
          });
        }
      }
    }
  },
};
