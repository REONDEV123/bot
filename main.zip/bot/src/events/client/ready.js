/**
 * Ready Event - Feathernodes Help Bot
 */

const { ActivityType } = require('discord.js');

module.exports = {
  name:  'ready',
  once:  true,
  execute: async (client, readyClient) => {
    console.log(`\n[READY] ✅ Logged in as: ${readyClient.user.tag}`);
    console.log(`[READY] 📊 Guilds: ${readyClient.guilds.cache.size}`);
    console.log(`[READY] 👥 Users: ${readyClient.users.cache.size}`);

    // Rotating status
    const statuses = [
      { name: '/help | Feathernodes Help',       type: ActivityType.Watching   },
      { name: 'your server 🛡️',                  type: ActivityType.Watching   },
      { name: 'music 🎵',                         type: ActivityType.Listening  },
      { name: 'tickets 🎫',                       type: ActivityType.Watching   },
      { name: 'feathernodes.xyz | by reondev',    type: ActivityType.Playing    },
    ];

    let index = 0;
    const setStatus = () => {
      const s = statuses[index++ % statuses.length];
      readyClient.user.setPresence({
        activities: [{ name: s.name, type: s.type }],
        status: 'online',
      });
    };

    setStatus();
    setInterval(setStatus, 15_000);
  },
};
