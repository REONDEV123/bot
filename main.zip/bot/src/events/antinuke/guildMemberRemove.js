const { handleKick } = require('../../systems/antinuke');
const { AuditLogEvent } = require('discord.js');

module.exports = {
  name: 'guildMemberRemove',
  once: false,
  execute: async (client, member) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    try {
      // Check if this was a kick (not a leave)
      const logs = await member.guild.fetchAuditLogs({ type: AuditLogEvent.MemberKick, limit: 1 });
      const entry = logs.entries.first();
      if (entry && entry.target?.id === member.id && (Date.now() - entry.createdTimestamp) < 5000) {
        await handleKick(member.guild, client, member);
      }
    } catch {}
  },
};
