const { handleMemberUpdate, handleBotAdd } = require('../../systems/antinuke');
module.exports = {
  name: 'guildMemberUpdate',
  once: false,
  execute: async (client, oldMember, newMember) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    await handleMemberUpdate(newMember.guild, client, oldMember, newMember);
  },
};
