const { handleChannelDelete } = require('../../systems/antinuke');
module.exports = {
  name: 'channelDelete',
  once: false,
  execute: async (client, channel) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    if (!channel.guild) return;
    await handleChannelDelete(channel.guild, client, channel);
  },
};
