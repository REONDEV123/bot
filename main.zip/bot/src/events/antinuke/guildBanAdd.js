const { handleBan } = require('../../systems/antinuke');
module.exports = {
  name: 'guildBanAdd',
  once: false,
  execute: async (client, ban) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    await handleBan(ban.guild, client, ban.user);
  },
};
