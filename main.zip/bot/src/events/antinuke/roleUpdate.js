const { handleRoleUpdate } = require('../../systems/antinuke');
module.exports = {
  name: 'roleUpdate',
  once: false,
  execute: async (client, oldRole, newRole) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    await handleRoleUpdate(newRole.guild, client, oldRole, newRole);
  },
};
