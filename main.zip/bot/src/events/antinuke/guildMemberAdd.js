const { handleBotAdd } = require('../../systems/antinuke');
module.exports = {
  name: 'guildMemberAdd',
  once: false,
  execute: async (client, member) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    if (member.user.bot) {
      await handleBotAdd(member.guild, client, member);
    }
  },
};
