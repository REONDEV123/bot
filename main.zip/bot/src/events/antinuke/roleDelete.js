const { handleRoleDelete } = require('../../systems/antinuke');
module.exports = {
  name: 'roleDelete',
  once: false,
  execute: async (client, role) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    await handleRoleDelete(role.guild, client, role);
  },
};
