const { handleWebhookCreate } = require('../../systems/antinuke');
module.exports = {
  name: 'webhookUpdate',
  once: false,
  execute: async (client, channel) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    if (!channel.guild) return;
    await handleWebhookCreate(channel.guild, client);
  },
};
