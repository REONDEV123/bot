const { handleGuildUpdate } = require('../../systems/antinuke');
module.exports = {
  name: 'guildUpdate',
  once: false,
  execute: async (client, oldGuild, newGuild) => {
    if (process.env.ANTINUKE_ENABLED === 'false') return;
    await handleGuildUpdate(newGuild, client, oldGuild, newGuild);
  },
};
