/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║       TICKET SYSTEM - Feathernodes Help Bot                  ║
 * ║   Advanced ticket system inspired by R.O.T.I Bot             ║
 * ║   Features: Categories, Transcripts, Claims, Panels         ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  AttachmentBuilder,
} = require('discord.js');
const { Colors, Emojis } = require('../utils/constants');
const { isSupport, isOwner } = require('../utils/permissions');

// ─── Ticket Categories ─────────────────────────────────────────────────────────
const TICKET_CATEGORIES = [
  { label: '🛠️ General Support',    value: 'general',  description: 'Get help with general questions',      emoji: '🛠️', color: Colors.INFO },
  { label: '💰 Billing & Payment',  value: 'billing',  description: 'Payment issues & billing support',     emoji: '💰', color: Colors.SUCCESS },
  { label: '🐛 Bug Report',         value: 'bug',      description: 'Report a bug or technical issue',      emoji: '🐛', color: Colors.ERROR },
  { label: '🤝 Partnership',        value: 'partner',  description: 'Business & partnership inquiries',     emoji: '🤝', color: Colors.MUSIC },
  { label: '🚨 Report a User',      value: 'report',   description: 'Report a rule-breaking user',         emoji: '🚨', color: Colors.MOD },
  { label: '💡 Suggestion',         value: 'suggest',  description: 'Share your suggestions & ideas',      emoji: '💡', color: Colors.WARNING },
  { label: '⭐ Premium Support',    value: 'premium',  description: 'Priority support for premium users',  emoji: '⭐', color: Colors.PRIMARY },
];

// ─── In-memory ticket store (use DB for production) ───────────────────────────
const openTickets = new Map(); // userId => channelId
const ticketData  = new Map(); // channelId => { userId, category, claimedBy, createdAt }
let   ticketCounter = 1;

// ─── Generate transcript (HTML) ───────────────────────────────────────────────
async function generateTranscript(channel) {
  try {
    const messages = await channel.messages.fetch({ limit: 100 });
    const sorted   = [...messages.values()].reverse();

    let html = `<!DOCTYPE html><html>
<head><meta charset="utf-8"><title>Ticket Transcript - ${channel.name}</title>
<style>
body { background: #36393f; color: #dcddde; font-family: Whitney, sans-serif; padding: 20px; }
.header { background: #2f3136; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
.header h1 { color: #fff; margin: 0; font-size: 1.5em; }
.header p  { color: #b9bbbe; margin: 5px 0 0; }
.message   { display: flex; margin-bottom: 20px; }
.avatar    { width: 40px; height: 40px; border-radius: 50%; margin-right: 15px; }
.msg-body  { flex: 1; }
.msg-author{ font-weight: 700; color: #fff; }
.msg-time  { font-size: 0.75em; color: #72767d; margin-left: 8px; }
.msg-content { margin-top: 4px; word-break: break-word; }
.embed { background: #2f3136; border-left: 4px solid #5865f2; padding: 10px 15px; border-radius: 4px; margin-top: 8px; }
.bot-tag { background: #5865f2; color: #fff; font-size: 0.7em; padding: 1px 4px; border-radius: 3px; margin-left: 5px; }
</style></head><body>
<div class="header">
  <h1>🎫 Ticket Transcript: #${channel.name}</h1>
  <p>Generated at ${new Date().toUTCString()} | Feathernodes Help Bot | Credit: reondev</p>
</div>\n`;

    for (const msg of sorted) {
      if (!msg.author) continue;
      const time    = new Date(msg.createdTimestamp).toUTCString();
      const botTag  = msg.author.bot ? '<span class="bot-tag">BOT</span>' : '';
      const content = msg.content?.replace(/</g, '&lt;').replace(/>/g, '&gt;') || '';
      const embeds  = msg.embeds.map(e => `<div class="embed"><strong>${e.title || ''}</strong><br>${e.description || ''}</div>`).join('');

      html += `<div class="message">
  <img class="avatar" src="${msg.author.displayAvatarURL({ size: 64 }) || 'https://cdn.discordapp.com/embed/avatars/0.png'}" onerror="this.src='https://cdn.discordapp.com/embed/avatars/0.png'">
  <div class="msg-body">
    <span class="msg-author">${msg.author.username || 'Unknown'}${botTag}</span>
    <span class="msg-time">${time}</span>
    <div class="msg-content">${content}${embeds}</div>
  </div>
</div>\n`;
    }

    html += '</body></html>';
    return html;
  } catch {
    return '<html><body>Error generating transcript.</body></html>';
  }
}

// ─── Create Ticket Panel ───────────────────────────────────────────────────────
async function createTicketPanel(channel, client) {
  const embed = new EmbedBuilder()
    .setColor(Colors.TICKET)
    .setTitle(`${Emojis.TICKET} Support Tickets`)
    .setDescription(
      `Welcome to **Feathernodes Help** Support!\n\n` +
      `To open a ticket, select a category from the dropdown below.\n\n` +
      `**Available Support Categories:**\n` +
      TICKET_CATEGORIES.map(c => `${c.emoji} **${c.label.replace(/^.{2}/, '')}** — ${c.description}`).join('\n') +
      `\n\n⚠️ **Please do not abuse the ticket system.**\nAbuse will result in a ban.`
    )
    .setImage('https://i.imgur.com/wSTFkRM.gif')
    .setThumbnail(client.user?.displayAvatarURL())
    .setFooter({ text: `Feathernodes Help | Made by Feathernodes Team | Credit: reondev`, iconURL: client.user?.displayAvatarURL() })
    .setTimestamp();

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('ticket_category_select')
    .setPlaceholder('📂 Select a ticket category...')
    .addOptions(TICKET_CATEGORIES.map(c => ({
      label:       c.label,
      value:       c.value,
      description: c.description,
      emoji:       c.emoji,
    })));

  const row = new ActionRowBuilder().addComponents(selectMenu);

  await channel.send({ embeds: [embed], components: [row] });
}

// ─── Open Ticket ───────────────────────────────────────────────────────────────
async function openTicket(interaction, client, category) {
  const { guild, user, member } = interaction;

  // Check if user already has an open ticket
  if (openTickets.has(user.id)) {
    const existingId = openTickets.get(user.id);
    const existing   = guild.channels.cache.get(existingId);
    if (existing) {
      return interaction.reply({
        content: `${Emojis.WARNING} You already have an open ticket: <#${existingId}>. Please close it before opening a new one.`,
        ephemeral: true,
      });
    } else {
      openTickets.delete(user.id);
    }
  }

  await interaction.deferReply({ ephemeral: true });

  const cat  = TICKET_CATEGORIES.find(c => c.value === category);
  const num  = String(ticketCounter++).padStart(4, '0');
  const name = `ticket-${num}-${user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 15)}`;

  // Find or create Tickets category
  let ticketCategory = guild.channels.cache.find(
    c => c.name === (process.env.TICKET_CATEGORY || 'Tickets') && c.type === ChannelType.GuildCategory
  );

  if (!ticketCategory) {
    ticketCategory = await guild.channels.create({
      name: process.env.TICKET_CATEGORY || 'Tickets',
      type: ChannelType.GuildCategory,
    });
  }

  // Set permissions
  const permissionOverwrites = [
    {
      id:   guild.id, // @everyone
      deny: [PermissionFlagsBits.ViewChannel],
    },
    {
      id:    user.id, // Ticket opener
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    },
    {
      id:    guild.members.me.id, // Bot
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    },
  ];

  // Add support role
  const supportRoleId = process.env.SUPPORT_ROLE_ID;
  if (supportRoleId && guild.roles.cache.has(supportRoleId)) {
    permissionOverwrites.push({
      id:    supportRoleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    });
  }

  // Create the channel
  const ticketChannel = await guild.channels.create({
    name,
    type:   ChannelType.GuildText,
    parent: ticketCategory.id,
    topic:  `Ticket by ${user.tag} | Category: ${cat?.label} | Status: Open`,
    permissionOverwrites,
    reason: `Ticket opened by ${user.tag}`,
  });

  // Store ticket data
  openTickets.set(user.id, ticketChannel.id);
  ticketData.set(ticketChannel.id, {
    userId:    user.id,
    category:  cat?.label || category,
    claimedBy: null,
    createdAt: new Date(),
    status:    'open',
    number:    num,
  });

  // Send ticket embed
  const embed = new EmbedBuilder()
    .setColor(cat?.color || Colors.TICKET)
    .setTitle(`${cat?.emoji || Emojis.TICKET} Ticket #${num} — ${cat?.label || category}`)
    .setDescription(
      `Thank you for contacting **Feathernodes Support**, <@${user.id}>!\n\n` +
      `**Category:** ${cat?.label || category}\n` +
      `**Status:** 🟢 Open\n` +
      `**Ticket ID:** \`#${num}\`\n\n` +
      `A support team member will assist you shortly.\n` +
      `Please **describe your issue in detail** below.\n\n` +
      `> 📌 Do not ping staff — they will respond as soon as possible.`
    )
    .setThumbnail(user.displayAvatarURL())
    .setFooter({ text: `Feathernodes Help | Credit: reondev`, iconURL: client.user?.displayAvatarURL() })
    .setTimestamp();

  const controlRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_close')
      .setLabel('🔒 Close Ticket')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('ticket_claim')
      .setLabel('👋 Claim Ticket')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('ticket_transcript')
      .setLabel('📋 Transcript')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('ticket_add_user')
      .setLabel('➕ Add User')
      .setStyle(ButtonStyle.Primary),
  );

  const mention = supportRoleId ? `<@&${supportRoleId}>` : '@here';
  await ticketChannel.send({
    content:   `<@${user.id}> ${mention}`,
    embeds:    [embed],
    components: [controlRow],
  });

  // Log ticket creation
  await logTicket(guild, client, 'OPEN', { user, channel: ticketChannel, num, category: cat?.label });

  await interaction.editReply({
    content: `${Emojis.SUCCESS} Ticket created! Please head to <#${ticketChannel.id}>`,
  });
}

// ─── Close Ticket ──────────────────────────────────────────────────────────────
async function closeTicket(interaction, client) {
  const { channel, guild, user, member } = interaction;
  const data = ticketData.get(channel.id);

  if (!data) {
    return interaction.reply({ content: `${Emojis.ERROR} This is not a valid ticket channel.`, ephemeral: true });
  }

  const isOwnerOfTicket = data.userId === user.id;
  const isSupportMember = isSupport(member, process.env.SUPPORT_ROLE_ID);

  if (!isOwnerOfTicket && !isSupportMember) {
    return interaction.reply({ content: `${Emojis.ERROR} You don't have permission to close this ticket.`, ephemeral: true });
  }

  // Confirmation
  const confirmEmbed = new EmbedBuilder()
    .setColor(Colors.WARNING)
    .setTitle(`${Emojis.WARNING} Close Ticket?`)
    .setDescription(
      `Are you sure you want to close this ticket?\n\n` +
      `A transcript will be saved and the channel will be deleted in **10 seconds**.`
    );

  const confirmRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_close_confirm')
      .setLabel('✅ Confirm Close')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('ticket_close_cancel')
      .setLabel('❌ Cancel')
      .setStyle(ButtonStyle.Secondary),
  );

  await interaction.reply({ embeds: [confirmEmbed], components: [confirmRow] });
}

// ─── Confirm Close ─────────────────────────────────────────────────────────────
async function confirmClose(interaction, client) {
  const { channel, guild, user } = interaction;
  const data = ticketData.get(channel.id);
  if (!data) return;

  await interaction.deferUpdate();

  const closingEmbed = new EmbedBuilder()
    .setColor(Colors.ERROR)
    .setDescription(`${Emojis.LOCK} Ticket is being closed. Saving transcript...`);

  await interaction.editReply({ embeds: [closingEmbed], components: [] });

  // Generate and send transcript
  const transcriptHtml  = await generateTranscript(channel);
  const transcriptFile  = Buffer.from(transcriptHtml, 'utf-8');
  const attachment      = new AttachmentBuilder(transcriptFile, { name: `transcript-${channel.name}.html` });

  // Send transcript to log channel
  const logChannelName = process.env.TICKET_LOG_CHANNEL || 'ticket-logs';
  const logChannel     = guild.channels.cache.find(c => c.name === logChannelName || c.id === logChannelName);

  if (logChannel) {
    const logEmbed = new EmbedBuilder()
      .setColor(Colors.LOG)
      .setTitle(`${Emojis.LOG} Ticket Closed — #${data.number}`)
      .addFields(
        { name: '👤 Opened By', value: `<@${data.userId}>`, inline: true },
        { name: '🎫 Category',  value: data.category,       inline: true },
        { name: '👋 Closed By', value: `<@${user.id}>`,     inline: true },
        { name: '🕐 Created',   value: `<t:${Math.floor(data.createdAt.getTime() / 1000)}:R>`, inline: true },
        { name: '📋 Transcript', value: 'Attached below',    inline: true },
      )
      .setFooter({ text: `Feathernodes Help | Credit: reondev`, iconURL: client.user?.displayAvatarURL() })
      .setTimestamp();

    await logChannel.send({ embeds: [logEmbed], files: [attachment] });
  }

  // DM transcript to ticket opener
  try {
    const ticketUser = await client.users.fetch(data.userId);
    const dmEmbed    = new EmbedBuilder()
      .setColor(Colors.INFO)
      .setTitle(`${Emojis.TICKET} Your ticket has been closed`)
      .setDescription(`Your ticket **#${data.number}** in **${guild.name}** was closed.\nA transcript of your ticket is attached below.`)
      .setFooter({ text: `Feathernodes Help | Credit: reondev` });
    await ticketUser.send({ embeds: [dmEmbed], files: [attachment] });
  } catch {}

  // Clean up
  openTickets.delete(data.userId);
  ticketData.delete(channel.id);

  // Delete channel after delay
  setTimeout(async () => {
    try { await channel.delete('[Ticket Closed]'); } catch {}
  }, 5000);
}

// ─── Claim Ticket ──────────────────────────────────────────────────────────────
async function claimTicket(interaction, client) {
  const { channel, member, user, guild } = interaction;
  const data = ticketData.get(channel.id);

  if (!data) {
    return interaction.reply({ content: `${Emojis.ERROR} Not a ticket channel.`, ephemeral: true });
  }

  if (!isSupport(member, process.env.SUPPORT_ROLE_ID)) {
    return interaction.reply({ content: `${Emojis.ERROR} Only support staff can claim tickets.`, ephemeral: true });
  }

  if (data.claimedBy) {
    return interaction.reply({
      content: `${Emojis.WARNING} This ticket is already claimed by <@${data.claimedBy}>.`,
      ephemeral: true,
    });
  }

  data.claimedBy = user.id;

  const embed = new EmbedBuilder()
    .setColor(Colors.SUCCESS)
    .setDescription(`${Emojis.SUCCESS} Ticket claimed by <@${user.id}>! They will be assisting you shortly.`);

  await channel.setTopic(`Ticket by <@${data.userId}> | Category: ${data.category} | Claimed by: ${user.tag} | Status: Claimed`);
  await interaction.reply({ embeds: [embed] });
}

// ─── Add User to Ticket ────────────────────────────────────────────────────────
async function addUserToTicket(interaction, client) {
  const { channel, member } = interaction;
  const data = ticketData.get(channel.id);
  if (!data) return;

  if (!isSupport(member, process.env.SUPPORT_ROLE_ID)) {
    return interaction.reply({ content: `${Emojis.ERROR} Only support staff can add users.`, ephemeral: true });
  }

  const modal = new ModalBuilder()
    .setCustomId('ticket_add_user_modal')
    .setTitle('Add User to Ticket')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('user_id_input')
          .setLabel('User ID to add')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Enter a Discord User ID...')
          .setRequired(true)
      )
    );

  await interaction.showModal(modal);
}

// ─── Ticket Logging ────────────────────────────────────────────────────────────
async function logTicket(guild, client, type, { user, channel, num, category } = {}) {
  const logChannelName = process.env.TICKET_LOG_CHANNEL || 'ticket-logs';
  const logChannel     = guild.channels.cache.find(c => c.name === logChannelName || c.id === logChannelName);
  if (!logChannel) return;

  const actions = {
    OPEN: { color: Colors.SUCCESS, title: 'Ticket Opened', emoji: '🟢' },
    CLOSE: { color: Colors.ERROR,  title: 'Ticket Closed', emoji: '🔴' },
  };

  const action = actions[type] || actions.OPEN;
  const embed  = new EmbedBuilder()
    .setColor(action.color)
    .setTitle(`${action.emoji} ${action.title}`)
    .addFields(
      { name: '👤 User',     value: `<@${user?.id}> (${user?.tag || user?.id})`, inline: true },
      { name: '🎫 Ticket',   value: `<#${channel?.id}> (#${num})`,                inline: true },
      { name: '📂 Category', value: category || 'General',                        inline: true },
    )
    .setThumbnail(user?.displayAvatarURL?.() || null)
    .setFooter({ text: `Feathernodes Help | Credit: reondev`, iconURL: client.user?.displayAvatarURL() })
    .setTimestamp();

  try { await logChannel.send({ embeds: [embed] }); } catch {}
}

module.exports = {
  createTicketPanel,
  openTicket,
  closeTicket,
  confirmClose,
  claimTicket,
  addUserToTicket,
  generateTranscript,
  TICKET_CATEGORIES,
  ticketData,
  openTickets,
};
