/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║       ANTINUKE SYSTEM - Feathernodes Help Bot                ║
 * ║   Real-time protection against server nukes/raids            ║
 * ║   Inspired by Wick Bot architecture                          ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * Detects and punishes:
 *  - Mass bans/kicks
 *  - Mass channel deletions
 *  - Mass role deletions/creations with dangerous permissions
 *  - Webhook abuse
 *  - Bot additions
 *  - Guild name/icon changes
 *  - @everyone mention spam
 */

const { PermissionFlagsBits, AuditLogEvent, EmbedBuilder } = require('discord.js');
const { AntiNukeThresholds, AntiNukeActions, Colors, Emojis } = require('../utils/constants');
const { checkAntiNukeWhitelist } = require('../utils/permissions');

// ─── In-Memory Action Tracker ─────────────────────────────────────────────────
// Structure: Map<guildId, Map<userId, Map<action, { count, timer }>>>
const actionTracker = new Map();

/**
 * Track an action for a user in a guild.
 * Returns true if the threshold is exceeded (= nuke detected).
 */
function trackAction(guildId, userId, action, threshold = AntiNukeThresholds.BAN_THRESHOLD) {
  if (!actionTracker.has(guildId)) actionTracker.set(guildId, new Map());
  const guildMap = actionTracker.get(guildId);

  if (!guildMap.has(userId)) guildMap.set(userId, new Map());
  const userMap = guildMap.get(userId);

  if (!userMap.has(action)) {
    userMap.set(action, { count: 0, timer: null });
  }

  const entry = userMap.get(action);
  entry.count += 1;

  // Reset after time window
  if (entry.timer) clearTimeout(entry.timer);
  entry.timer = setTimeout(() => {
    userMap.delete(action);
  }, AntiNukeThresholds.TIME_WINDOW);

  return entry.count >= threshold;
}

/**
 * Reset action tracker for a user
 */
function resetTracker(guildId, userId, action) {
  if (actionTracker.has(guildId)) {
    const guildMap = actionTracker.get(guildId);
    if (guildMap.has(userId)) {
      guildMap.get(userId).delete(action);
    }
  }
}

// ─── Get audit log executor ───────────────────────────────────────────────────
async function getAuditLogExecutor(guild, auditEvent, targetId = null) {
  try {
    await new Promise(r => setTimeout(r, 800)); // Wait for Discord audit log
    const logs = await guild.fetchAuditLogs({ type: auditEvent, limit: 5 });
    const entry = logs.entries.find(e => {
      if (targetId) return e.target?.id === targetId || e.targetId === targetId;
      return true;
    }) || logs.entries.first();
    return entry?.executor || null;
  } catch {
    return null;
  }
}

// ─── Send alert to antinuke log channel ──────────────────────────────────────
async function sendAlert(guild, client, { action, executor, punishment, details }) {
  const logChannelName = process.env.ANTINUKE_LOG_CHANNEL || 'antinuke-logs';
  const logChannel = guild.channels.cache.find(
    c => c.name === logChannelName || c.id === logChannelName
  );

  if (!logChannel) return;

  const embed = new EmbedBuilder()
    .setColor(Colors.ANTINUKE)
    .setTitle(`${Emojis.SHIELD} AntiNuke Alert — ${action}`)
    .setDescription(
      `**User:** ${executor ? `<@${executor.id}> (${executor.tag || executor.id})` : 'Unknown'}\n` +
      `**Action:** ${action}\n` +
      `**Punishment:** ${punishment}\n` +
      `**Details:** ${details}`
    )
    .setThumbnail(executor?.displayAvatarURL?.() || null)
    .setFooter({ text: `Feathernodes Help AntiNuke | Credit: reondev`, iconURL: client.user?.displayAvatarURL() })
    .setTimestamp();

  try {
    await logChannel.send({ embeds: [embed] });
  } catch {}
}

// ─── Punishment Handler ───────────────────────────────────────────────────────
async function punish(guild, client, executor, action, details) {
  if (!executor) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  // Don't punish bots managed by Discord or if executor is guild owner
  if (executor.id === guild.ownerId) return;

  const punishment = 'BAN'; // Configurable: BAN | KICK | STRIP_ROLES
  let punishmentApplied = 'None';

  try {
    // Fetch member
    const member = await guild.members.fetch(executor.id).catch(() => null);
    if (!member) {
      // User already left — still ban
      await guild.bans.create(executor.id, { reason: `[AntiNuke] ${action}: ${details}` });
      punishmentApplied = `Banned (was not in server)`;
    } else {
      // Check bot's own position
      const botMember = guild.members.me;
      if (botMember.roles.highest.comparePositionTo(member.roles.highest) <= 0) {
        punishmentApplied = `Could not punish (missing permissions/hierarchy)`;
      } else {
        if (punishment === 'BAN') {
          await member.ban({ reason: `[AntiNuke] ${action}: ${details}`, deleteMessageSeconds: 0 });
          punishmentApplied = `Banned`;
        } else if (punishment === 'KICK') {
          await member.kick(`[AntiNuke] ${action}: ${details}`);
          punishmentApplied = `Kicked`;
        } else if (punishment === 'STRIP_ROLES') {
          const roles = member.roles.cache.filter(r => r.id !== guild.id);
          await member.roles.remove(roles, `[AntiNuke] ${action}`);
          punishmentApplied = `Roles Stripped`;
        }
      }
    }
  } catch (err) {
    punishmentApplied = `Error: ${err.message}`;
  }

  console.log(`[ANTINUKE] 🛡️ ${action} by ${executor.id} in ${guild.name} → ${punishmentApplied}`);

  await sendAlert(guild, client, {
    action,
    executor,
    punishment: punishmentApplied,
    details,
  });

  resetTracker(guild.id, executor.id, action);
}

// ─── AntiNuke Event Handlers ──────────────────────────────────────────────────

/**
 * Handle member bans (Mass Ban Detection)
 */
async function handleBan(guild, client, user) {
  const executor = await getAuditLogExecutor(guild, AuditLogEvent.MemberBan, user.id);
  if (!executor || executor.id === client.user.id) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  const exceeded = trackAction(guild.id, executor.id, AntiNukeActions.MASS_BAN, AntiNukeThresholds.BAN_THRESHOLD);
  if (exceeded) {
    await punish(guild, client, executor, 'Mass Ban', `Banned ${AntiNukeThresholds.BAN_THRESHOLD}+ members rapidly`);
  }
}

/**
 * Handle member kicks (Mass Kick Detection)
 */
async function handleKick(guild, client, member) {
  const executor = await getAuditLogExecutor(guild, AuditLogEvent.MemberKick, member.id);
  if (!executor || executor.id === client.user.id) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  const exceeded = trackAction(guild.id, executor.id, AntiNukeActions.MASS_KICK, AntiNukeThresholds.KICK_THRESHOLD);
  if (exceeded) {
    await punish(guild, client, executor, 'Mass Kick', `Kicked ${AntiNukeThresholds.KICK_THRESHOLD}+ members rapidly`);
  }
}

/**
 * Handle channel deletions (Mass Channel Delete Detection)
 */
async function handleChannelDelete(guild, client, channel) {
  const executor = await getAuditLogExecutor(guild, AuditLogEvent.ChannelDelete, channel.id);
  if (!executor || executor.id === client.user.id) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  const exceeded = trackAction(guild.id, executor.id, AntiNukeActions.MASS_CHANNEL_DELETE, AntiNukeThresholds.CHANNEL_DELETE_THRESHOLD);
  if (exceeded) {
    await punish(guild, client, executor, 'Mass Channel Delete', `Deleted ${AntiNukeThresholds.CHANNEL_DELETE_THRESHOLD}+ channels rapidly`);
  }
}

/**
 * Handle role deletions (Mass Role Delete Detection)
 */
async function handleRoleDelete(guild, client, role) {
  const executor = await getAuditLogExecutor(guild, AuditLogEvent.RoleDelete, role.id);
  if (!executor || executor.id === client.user.id) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  const exceeded = trackAction(guild.id, executor.id, AntiNukeActions.MASS_ROLE_DELETE, AntiNukeThresholds.ROLE_DELETE_THRESHOLD);
  if (exceeded) {
    await punish(guild, client, executor, 'Mass Role Delete', `Deleted ${AntiNukeThresholds.ROLE_DELETE_THRESHOLD}+ roles rapidly`);
  }
}

/**
 * Handle role updates (Dangerous Permission Grant Detection)
 */
async function handleRoleUpdate(guild, client, oldRole, newRole) {
  const DANGEROUS = [
    PermissionFlagsBits.Administrator,
    PermissionFlagsBits.ManageGuild,
    PermissionFlagsBits.ManageRoles,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.BanMembers,
    PermissionFlagsBits.KickMembers,
    PermissionFlagsBits.ManageWebhooks,
  ];

  const newPerms   = newRole.permissions.toArray();
  const oldPerms   = oldRole.permissions.toArray();
  const addedDangerousPerms = DANGEROUS.filter(p => newRole.permissions.has(p) && !oldRole.permissions.has(p));

  if (addedDangerousPerms.length === 0) return;

  const executor = await getAuditLogExecutor(guild, AuditLogEvent.RoleUpdate, newRole.id);
  if (!executor || executor.id === client.user.id) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  const permNames = addedDangerousPerms.map(p => {
    const key = Object.keys(PermissionFlagsBits).find(k => PermissionFlagsBits[k] === p);
    return key || String(p);
  });

  await punish(guild, client, executor, 'Dangerous Role Update', `Added dangerous permissions to role @${newRole.name}: ${permNames.join(', ')}`);
}

/**
 * Handle member updates (Dangerous Role Assign Detection)
 */
async function handleMemberUpdate(guild, client, oldMember, newMember) {
  const addedRoles = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
  if (addedRoles.size === 0) return;

  const DANGEROUS_PERMS = [
    PermissionFlagsBits.Administrator,
    PermissionFlagsBits.ManageGuild,
    PermissionFlagsBits.ManageRoles,
    PermissionFlagsBits.BanMembers,
    PermissionFlagsBits.KickMembers,
  ];

  const hasDangerous = addedRoles.some(r =>
    DANGEROUS_PERMS.some(p => r.permissions.has(p))
  );
  if (!hasDangerous) return;
  if (checkAntiNukeWhitelist(newMember.id)) return;

  const executor = await getAuditLogExecutor(guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
  if (!executor || executor.id === client.user.id) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  const roleNames = addedRoles.map(r => `@${r.name}`).join(', ');
  await sendAlert(guild, client, {
    action:      'Suspicious Role Assignment',
    executor,
    punishment:  'Alert Only',
    details:     `Gave dangerous role(s) ${roleNames} to <@${newMember.id}>`,
  });
}

/**
 * Handle webhook creations (Webhook Spam Detection)
 */
async function handleWebhookCreate(guild, client) {
  try {
    const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.WebhookCreate, limit: 1 });
    const entry = logs.entries.first();
    if (!entry) return;

    const executor = entry.executor;
    if (!executor || executor.id === client.user.id) return;
    if (checkAntiNukeWhitelist(executor.id)) return;

    const exceeded = trackAction(guild.id, executor.id, AntiNukeActions.MASS_WEBHOOK_CREATE, AntiNukeThresholds.WEBHOOK_THRESHOLD);
    if (exceeded) {
      await punish(guild, client, executor, 'Webhook Abuse', `Created ${AntiNukeThresholds.WEBHOOK_THRESHOLD}+ webhooks rapidly`);
    }
  } catch {}
}

/**
 * Handle bot additions (Unauthorized Bot Addition)
 */
async function handleBotAdd(guild, client, member) {
  if (!member.user.bot) return;
  if (member.id === client.user.id) return;

  const executor = await getAuditLogExecutor(guild, AuditLogEvent.BotAdd, member.id);
  if (!executor) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  await sendAlert(guild, client, {
    action:     'Unauthorized Bot Added',
    executor,
    punishment: 'Alert (Kick bot to protect)',
    details:    `Bot ${member.user.tag} (${member.id}) was added to the server`,
  });

  // Auto-kick the added bot
  try {
    await member.kick('[AntiNuke] Unauthorized bot addition');
  } catch {}
}

/**
 * Handle guild updates (Server Vandalism Detection)
 */
async function handleGuildUpdate(guild, client, oldGuild, newGuild) {
  const executor = await getAuditLogExecutor(guild, AuditLogEvent.GuildUpdate);
  if (!executor || executor.id === client.user.id) return;
  if (checkAntiNukeWhitelist(executor.id)) return;

  const changes = [];
  if (oldGuild.name !== newGuild.name) changes.push(`Name: "${oldGuild.name}" → "${newGuild.name}"`);
  if (oldGuild.icon !== newGuild.icon) changes.push(`Icon changed`);
  if (oldGuild.banner !== newGuild.banner) changes.push(`Banner changed`);
  if (oldGuild.verificationLevel !== newGuild.verificationLevel) changes.push(`Verification level changed`);

  if (changes.length === 0) return;

  await sendAlert(guild, client, {
    action:     'Server Update',
    executor,
    punishment: 'Alert Only',
    details:    changes.join('\n'),
  });
}

module.exports = {
  handleBan,
  handleKick,
  handleChannelDelete,
  handleRoleDelete,
  handleRoleUpdate,
  handleMemberUpdate,
  handleWebhookCreate,
  handleBotAdd,
  handleGuildUpdate,
  trackAction,
  resetTracker,
};
