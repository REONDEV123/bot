/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          FEATHERNODES HELP - All-in-One Discord Bot          ║
 * ║              Made by Feathernodes Team                       ║
 * ║                  Credit: reondev                             ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

require('dotenv').config();
const { Client, GatewayIntentBits, Collection, Partials, ActivityType } = require('discord.js');
const fs = require('fs');
const path = require('path');

// ─── Client Initialization ───────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildScheduledEvents,
    GatewayIntentBits.AutoModerationConfiguration,
    GatewayIntentBits.AutoModerationExecution,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction, Partials.GuildMember],
  allowedMentions: { parse: ['users', 'roles'], repliedUser: true },
});

// ─── Collections ─────────────────────────────────────────────────────────────
client.commands      = new Collection();
client.aliases       = new Collection();
client.cooldowns     = new Collection();
client.tickets       = new Collection(); // guildId => Map<userId, channelId>
client.antinuke      = new Collection(); // guildId => config
client.actionTracker = new Collection(); // track rapid destructive actions

// ─── Load Handlers ────────────────────────────────────────────────────────────
const handlersPath = path.join(__dirname, 'src', 'handlers');
const handlerFiles = fs.readdirSync(handlersPath).filter(f => f.endsWith('.js'));
for (const file of handlerFiles) {
  require(path.join(handlersPath, file))(client);
}

// ─── Login ────────────────────────────────────────────────────────────────────
client.login(process.env.DISCORD_TOKEN).then(() => {
  console.log('\n╔══════════════════════════════════════════════╗');
  console.log('║   FEATHERNODES HELP BOT - Online & Ready!   ║');
  console.log('║          Made by Feathernodes Team           ║');
  console.log('║              Credit: reondev                 ║');
  console.log('╚══════════════════════════════════════════════╝\n');
}).catch(err => {
  console.error('[FATAL] Failed to login:', err.message);
  process.exit(1);
});

// ─── Graceful Shutdown ────────────────────────────────────────────────────────
process.on('SIGINT',  () => { client.destroy(); process.exit(0); });
process.on('SIGTERM', () => { client.destroy(); process.exit(0); });
process.on('unhandledRejection', err => console.error('[UnhandledRejection]', err));
process.on('uncaughtException',  err => console.error('[UncaughtException]', err));

module.exports = client;
