"""
╔══════════════════════════════════════════════════════════════╗
║         FEATHERNODES HELP - Bot Launcher (Python)            ║
║             Made by Feathernodes Team                        ║
║                 Credit: reondev                              ║
╚══════════════════════════════════════════════════════════════╝

This file acts as a Python-based launcher/process manager for the
Feathernodes Help Discord Bot (Node.js). It monitors the bot process,
auto-restarts on crash, and provides a clean startup interface.

Usage: python main.py
"""

import subprocess
import sys
import os
import time
import signal
import datetime

# ─── ANSI Colors ──────────────────────────────────────────────
RED     = '\033[91m'
GREEN   = '\033[92m'
YELLOW  = '\033[93m'
CYAN    = '\033[96m'
MAGENTA = '\033[95m'
BLUE    = '\033[94m'
WHITE   = '\033[97m'
RESET   = '\033[0m'
BOLD    = '\033[1m'

BANNER = f"""
{CYAN}{BOLD}
╔══════════════════════════════════════════════════════════════╗
║          FEATHERNODES HELP - All-in-One Discord Bot          ║
║              Made by Feathernodes Team                       ║
║                  Credit: {MAGENTA}reondev{CYAN}                             ║
╠══════════════════════════════════════════════════════════════╣
║  Features:                                                   ║
║  🎫 Advanced Ticket System (R.O.T.I. Style)                  ║
║  🛡️  Real Anti-Nuke Protection (Wick Style)                  ║
║  🎵  Full Music System (DisTube)                             ║
║  🔨  Complete Moderation Suite                               ║
║  📊  Server Statistics & Logging                             ║
╚══════════════════════════════════════════════════════════════╝
{RESET}"""

def log(level, message):
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    colors = {
        'INFO':    GREEN,
        'WARN':    YELLOW,
        'ERROR':   RED,
        'SUCCESS': CYAN,
        'RESTART': MAGENTA,
    }
    color = colors.get(level, WHITE)
    print(f"{color}[{now}] [{level}] {message}{RESET}")

def check_node():
    """Verify Node.js is installed."""
    try:
        result = subprocess.run(['node', '--version'], capture_output=True, text=True)
        version = result.stdout.strip()
        log('INFO', f'Node.js detected: {version}')
        return True
    except FileNotFoundError:
        log('ERROR', 'Node.js is not installed! Please install Node.js v18+ from https://nodejs.org')
        return False

def check_env():
    """Verify .env file exists."""
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    if not os.path.exists(env_path):
        log('WARN', '.env file not found! Copying from .env.example...')
        example = os.path.join(os.path.dirname(__file__), '.env.example')
        if os.path.exists(example):
            import shutil
            shutil.copy(example, env_path)
            log('WARN', 'Please edit .env and fill in your credentials, then restart.')
            sys.exit(1)
        else:
            log('ERROR', 'No .env or .env.example found! Please create a .env file.')
            sys.exit(1)
    log('INFO', '.env file found.')

def install_dependencies():
    """Install Node.js dependencies if needed."""
    node_modules = os.path.join(os.path.dirname(__file__), 'node_modules')
    if not os.path.exists(node_modules):
        log('INFO', 'Installing Node.js dependencies (npm install)...')
        result = subprocess.run(
            ['npm', 'install'],
            cwd=os.path.dirname(__file__),
            capture_output=False
        )
        if result.returncode != 0:
            log('ERROR', 'npm install failed! Check your internet connection.')
            sys.exit(1)
        log('SUCCESS', 'Dependencies installed successfully!')
    else:
        log('INFO', 'Dependencies already installed.')

def run_bot():
    """Launch the bot with auto-restart on crash."""
    bot_script  = os.path.join(os.path.dirname(__file__), 'index.js')
    max_crashes = 10
    crash_count = 0
    restart_delay = 5  # seconds

    log('SUCCESS', 'Starting Feathernodes Help Bot...')

    while crash_count < max_crashes:
        start_time = time.time()
        try:
            process = subprocess.Popen(
                ['node', bot_script],
                cwd=os.path.dirname(__file__)
            )

            def handle_signal(sig, frame):
                log('INFO', 'Shutdown signal received. Stopping bot...')
                process.terminate()
                sys.exit(0)

            signal.signal(signal.SIGINT,  handle_signal)
            signal.signal(signal.SIGTERM, handle_signal)

            process.wait()
            exit_code = process.returncode
            elapsed   = time.time() - start_time

            if elapsed > 60:
                crash_count = 0  # Reset crash counter if ran >60s

            if exit_code == 0:
                log('INFO', 'Bot exited cleanly.')
                break

            crash_count += 1
            log('RESTART', f'Bot crashed (exit code: {exit_code}). Restart {crash_count}/{max_crashes} in {restart_delay}s...')
            time.sleep(restart_delay)
            restart_delay = min(restart_delay * 2, 60)  # Exponential backoff

        except KeyboardInterrupt:
            log('INFO', 'Keyboard interrupt. Shutting down...')
            break
        except Exception as e:
            log('ERROR', f'Unexpected error: {e}')
            crash_count += 1
            time.sleep(restart_delay)

    if crash_count >= max_crashes:
        log('ERROR', f'Bot crashed {max_crashes} times. Giving up. Check logs for errors.')

def main():
    print(BANNER)
    log('INFO', 'Feathernodes Help Bot Launcher starting...')

    if not check_node():
        sys.exit(1)

    check_env()
    install_dependencies()
    run_bot()

if __name__ == '__main__':
    main()
